/**
 * Edmonds-Karp Maximum Flow Algorithm for Hospital Resource Allocation (CO4)
 * Uses Breadth-First Search (BFS) to find shortest augmenting paths in residual graph.
 * Time Complexity: O(V * E^2)
 * Space Complexity: O(V + E)
 */

export class EdmondsKarpNetwork {
  constructor() {
    this.nodes = []; // list of node names/IDs
    this.nodeMap = new Map(); // name -> index
    this.capacity = []; // 2D matrix capacity[u][v]
    this.flow = []; // 2D matrix flow[u][v]
  }

  addNode(name, label, type) {
    if (this.nodeMap.has(name)) return this.nodeMap.get(name);
    const idx = this.nodes.length;
    this.nodes.push({ id: name, label: label || name, type: type || 'GENERIC', idx });
    this.nodeMap.set(name, idx);
    return idx;
  }

  addEdge(uName, vName, cap) {
    const u = this.addNode(uName);
    const v = this.addNode(vName);

    // Expand matrices if needed
    this.ensureMatrixSize();

    this.capacity[u][v] += cap;
  }

  ensureMatrixSize() {
    const n = this.nodes.length;
    while (this.capacity.length < n) {
      this.capacity.push(new Array(n).fill(0));
      this.flow.push(new Array(n).fill(0));
    }
    for (let i = 0; i < this.capacity.length; i++) {
      while (this.capacity[i].length < n) {
        this.capacity[i].push(0);
        this.flow[i].push(0);
      }
    }
  }

  /**
   * BFS helper to find shortest augmenting path from source to sink in residual graph.
   * Returns parent array or null if no path exists.
   */
  bfs(sourceIdx, sinkIdx) {
    const n = this.nodes.length;
    const parent = new Array(n).fill(-1);
    const visited = new Array(n).fill(false);
    const queue = [sourceIdx];

    visited[sourceIdx] = true;

    while (queue.length > 0) {
      const u = queue.shift();

      if (u === sinkIdx) break;

      for (let v = 0; v < n; v++) {
        // Residual capacity = capacity[u][v] - flow[u][v]
        const residual = this.capacity[u][v] - this.flow[u][v];
        if (!visited[v] && residual > 0) {
          visited[v] = true;
          parent[v] = u;
          queue.push(v);
        }
      }
    }

    return visited[sinkIdx] ? parent : null;
  }

  /**
   * Compute Edmonds-Karp Max Flow
   */
  computeMaxFlow(sourceName = 'SOURCE', sinkName = 'SINK') {
    const startTime = performance.now();

    this.ensureMatrixSize();
    const sourceIdx = this.nodeMap.get(sourceName);
    const sinkIdx = this.nodeMap.get(sinkName);

    if (sourceIdx === undefined || sinkIdx === undefined) {
      return {
        maxFlow: 0,
        augmentingPaths: [],
        nodesCount: this.nodes.length,
        edgesCount: 0,
        minCutEdges: [],
        allocatedFlows: [],
        executionTimeMs: 0
      };
    }

    let maxFlow = 0;
    const augmentingPaths = [];
    const n = this.nodes.length;

    // Reset flow matrix
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) {
        this.flow[i][j] = 0;
      }
    }

    let parentPath = this.bfs(sourceIdx, sinkIdx);

    while (parentPath) {
      // Find bottleneck capacity along the path
      let pathFlow = Infinity;
      let curr = sinkIdx;
      const pathNodes = [];

      while (curr !== sourceIdx) {
        pathNodes.push(this.nodes[curr].label);
        const prev = parentPath[curr];
        const residual = this.capacity[prev][curr] - this.flow[prev][curr];
        pathFlow = Math.min(pathFlow, residual);
        curr = prev;
      }
      pathNodes.push(this.nodes[sourceIdx].label);
      pathNodes.reverse();

      // Update residual graph flows
      curr = sinkIdx;
      while (curr !== sourceIdx) {
        const prev = parentPath[curr];
        this.flow[prev][curr] += pathFlow;
        this.flow[curr][prev] -= pathFlow; // Reverse edge residual update
        curr = prev;
      }

      maxFlow += pathFlow;

      augmentingPaths.push({
        pathNumber: augmentingPaths.length + 1,
        path: pathNodes.join(' ➔ '),
        bottleneck: pathFlow,
        cumulativeFlow: maxFlow
      });

      parentPath = this.bfs(sourceIdx, sinkIdx);
    }

    // Identify Min-Cut: reachable nodes in residual graph from source
    const reachable = new Array(n).fill(false);
    const queue = [sourceIdx];
    reachable[sourceIdx] = true;

    while (queue.length > 0) {
      const u = queue.shift();
      for (let v = 0; v < n; v++) {
        if (!reachable[v] && this.capacity[u][v] - this.flow[u][v] > 0) {
          reachable[v] = true;
          queue.push(v);
        }
      }
    }

    const minCutEdges = [];
    let edgesCount = 0;
    const allocatedFlows = [];

    for (let u = 0; u < n; u++) {
      for (let v = 0; v < n; v++) {
        if (this.capacity[u][v] > 0) {
          edgesCount++;
          // An edge (u, v) is in Min-Cut if u is reachable and v is not
          if (reachable[u] && !reachable[v]) {
            minCutEdges.push({
              from: this.nodes[u].label,
              to: this.nodes[v].label,
              capacity: this.capacity[u][v],
              flow: this.flow[u][v]
            });
          }

          if (this.flow[u][v] > 0) {
            allocatedFlows.push({
              from: this.nodes[u].label,
              to: this.nodes[v].label,
              flow: this.flow[u][v],
              capacity: this.capacity[u][v],
              utilization: Math.round((this.flow[u][v] / this.capacity[u][v]) * 100)
            });
          }
        }
      }
    }

    const endTime = performance.now();
    const executionTimeMs = parseFloat((endTime - startTime).toFixed(3));

    return {
      maxFlow,
      nodesCount: n,
      edgesCount,
      augmentingPaths,
      minCutEdges,
      allocatedFlows,
      nodes: this.nodes,
      flowMatrix: this.flow,
      capacityMatrix: this.capacity,
      executionTimeMs
    };
  }
}

/**
 * Creates and runs hospital resource flow network using Edmonds-Karp.
 */
export const runHospitalEdmondsKarp = (patients = [], resources = []) => {
  const net = new EdmondsKarpNetwork();

  // Source and Sink
  net.addNode('SOURCE', 'SOURCE (Hospital Reception)', 'SOURCE');
  net.addNode('SINK', 'SINK (Complete Care)', 'SINK');

  // Resource nodes setup with defaults if empty
  const defaultResources = [
    { id: 'RES_OR_GEN', name: 'General OR Suite', type: 'OR', capacity: 3 },
    { id: 'RES_OR_CARD', name: 'Cardiac OR Suite', type: 'OR', capacity: 2 },
    { id: 'RES_OR_ORTHO', name: 'Orthopedic OR Suite', type: 'OR', capacity: 2 },
    { id: 'RES_ICU', name: 'ICU Recovery Bed', type: 'BED', capacity: 4 },
    { id: 'RES_GEN_BED', name: 'General Ward Bed', type: 'BED', capacity: 5 },
    { id: 'RES_ANESTHESIA', name: 'Anesthesiology Team', type: 'STAFF', capacity: 3 }
  ];

  const resourceNodes = resources.length > 0 ? resources : defaultResources;

  // Add Edges from Resource Nodes to SINK
  resourceNodes.forEach(res => {
    net.addNode(res.id, res.name, 'RESOURCE');
    net.addEdge(res.id, 'SINK', res.capacity);
  });

  // Patient cases setup
  const patientCases = patients.length > 0 ? patients.slice(0, 8) : [
    { patientId: 'P1', name: 'Robert Vance (Cardiac Emergency)', dept: 'Cardiology', reqOR: 'RES_OR_CARD', reqBed: 'RES_ICU' },
    { patientId: 'P2', name: 'Elena Rostova (CABG Bypass)', dept: 'Cardiology', reqOR: 'RES_OR_CARD', reqBed: 'RES_ICU' },
    { patientId: 'P3', name: 'Michael Chang (Femur Fracture)', dept: 'Orthopedics', reqOR: 'RES_OR_ORTHO', reqBed: 'RES_GEN_BED' },
    { patientId: 'P4', name: 'Sophia Patel (Gallbladder)', dept: 'General Surgery', reqOR: 'RES_OR_GEN', reqBed: 'RES_GEN_BED' },
    { patientId: 'P5', name: 'James Wilson (Craniotomy)', dept: 'Neurology', reqOR: 'RES_OR_CARD', reqBed: 'RES_ICU' },
    { patientId: 'P6', name: 'Priya Sharma (Knee Arthroplasty)', dept: 'Orthopedics', reqOR: 'RES_OR_ORTHO', reqBed: 'RES_GEN_BED' },
    { patientId: 'P7', name: 'Jessica Alba (Abdominal Trauma)', dept: 'Emergency', reqOR: 'RES_OR_GEN', reqBed: 'RES_ICU' }
  ];

  let allocatedPatientsCount = 0;

  // Connect SOURCE -> Patient -> Target Resources
  patientCases.forEach((p, idx) => {
    const pId = p.patientId || p.id || `PAT_${idx}`;
    const pLabel = p.name || `Patient ${idx + 1}`;

    net.addNode(pId, pLabel, 'PATIENT');
    net.addEdge('SOURCE', pId, 1); // Each patient needs 1 flow unit

    // Map department to suitable OR
    let targetOR = p.reqOR;
    if (!targetOR) {
      if (p.department === 'Cardiology' || p.surgeryType?.includes('Bypass') || p.surgeryType?.includes('Cardiac')) targetOR = 'RES_OR_CARD';
      else if (p.department === 'Orthopedics' || p.surgeryType?.includes('Fracture') || p.surgeryType?.includes('Knee')) targetOR = 'RES_OR_ORTHO';
      else targetOR = 'RES_OR_GEN';
    }

    let targetBed = p.reqBed;
    if (!targetBed) {
      if (p.priority === 1 || p.priorityLabel === 'EMERGENCY' || p.department === 'Cardiology') targetBed = 'RES_ICU';
      else targetBed = 'RES_GEN_BED';
    }

    // Connect Patient -> Target OR & Bed
    net.addEdge(pId, targetOR, 1);
  });

  const result = net.computeMaxFlow('SOURCE', 'SINK');

  // Determine how many patients received allocation
  const patientNodesCount = patientCases.length;
  const allocatedCount = result.allocatedFlows.filter(f => f.from.includes('SOURCE') || f.from.includes('Patient') || f.from.includes('PAT')).length;

  return {
    ...result,
    totalPatients: patientNodesCount,
    allocatedPatients: Math.min(result.maxFlow, patientNodesCount),
    unallocatedPatients: Math.max(0, patientNodesCount - Math.min(result.maxFlow, patientNodesCount))
  };
};
