import React, { useState, useEffect } from 'react';
import { runPriorityScheduler, PRIORITY_MAP } from '../../algorithms/co1/hospitalPriorityScheduler';
import { getItem } from '../../services/storage';
import { Play, RefreshCw, Clock, Layers, ShieldAlert, CheckCircle, Info, Database } from 'lucide-react';

const CO1PriorityScheduler = () => {
  const [patientData, setPatientData] = useState([]);
  const [result, setResult] = useState(null);
  const [isDemoData, setIsDemoData] = useState(false);
  const [customPatient, setCustomPatient] = useState({
    name: '',
    surgeryType: '',
    priority: 1,
    waitingHours: 12,
    expectedSurgeryDuration: 90
  });

  // Load patient data from localStorage or fallback demo data
  const loadData = () => {
    const localPatients = getItem('medischedule_patients', []);
    if (localPatients && localPatients.length > 0) {
      setPatientData(localPatients);
      setIsDemoData(false);
    } else {
      // Demo dataset
      const demoPatients = [
        { patientId: 'DEMO-1', name: 'Robert Vance', surgeryType: 'Emergency Cardiac Bypass (CABG)', priority: 1, priorityLabel: 'EMERGENCY', admissionDate: new Date(Date.now() - 3600000 * 24).toISOString(), expectedSurgeryDuration: 180 },
        { patientId: 'DEMO-2', name: 'Elena Rostova', surgeryType: 'Acute Appendectomy', priority: 1, priorityLabel: 'EMERGENCY', admissionDate: new Date(Date.now() - 3600000 * 8).toISOString(), expectedSurgeryDuration: 60 },
        { patientId: 'DEMO-3', name: 'Michael Chang', surgeryType: 'Femur Fracture Repair', priority: 2, priorityLabel: 'URGENT', admissionDate: new Date(Date.now() - 3600000 * 18).toISOString(), expectedSurgeryDuration: 120 },
        { patientId: 'DEMO-4', name: 'Sophia Patel', surgeryType: 'Laparoscopic Cholecystectomy', priority: 3, priorityLabel: 'HIGH', admissionDate: new Date(Date.now() - 3600000 * 36).toISOString(), expectedSurgeryDuration: 90 },
        { patientId: 'DEMO-5', name: 'David Miller', surgeryType: 'Inguinal Hernia Repair', priority: 4, priorityLabel: 'NORMAL', admissionDate: new Date(Date.now() - 3600000 * 48).toISOString(), expectedSurgeryDuration: 60 },
        { patientId: 'DEMO-6', name: 'Priya Sharma', surgeryType: 'Elective Knee Arthroplasty', priority: 5, priorityLabel: 'ROUTINE', admissionDate: new Date(Date.now() - 3600000 * 72).toISOString(), expectedSurgeryDuration: 120 }
      ];
      setPatientData(demoPatients);
      setIsDemoData(true);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRunAlgorithm = () => {
    const output = runPriorityScheduler(patientData);
    setResult(output);
  };

  const handleAddCustomPatient = (e) => {
    e.preventDefault();
    if (!customPatient.name) return;

    const newCase = {
      patientId: `PAT-NEW-${Date.now().toString().slice(-4)}`,
      name: customPatient.name,
      surgeryType: customPatient.surgeryType || 'Surgical Procedure',
      priority: parseInt(customPatient.priority, 10),
      priorityLabel: PRIORITY_MAP[customPatient.priority]?.label || 'NORMAL',
      admissionDate: new Date(Date.now() - 3600000 * parseInt(customPatient.waitingHours || 1, 10)).toISOString(),
      expectedSurgeryDuration: parseInt(customPatient.expectedSurgeryDuration, 10) || 60
    };

    const updated = [newCase, ...patientData];
    setPatientData(updated);
    setCustomPatient({ name: '', surgeryType: '', priority: 1, waitingHours: 12, expectedSurgeryDuration: 90 });
  };

  return (
    <div className="card" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
      {/* Module Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.35rem' }}>
            <span className="badge badge-scheduled" style={{ fontSize: '0.75rem', fontWeight: 700 }}>CO1</span>
            <h2 style={{ fontSize: '1.3rem', color: 'var(--primary-text)', margin: 0 }}>
              Priority Queue + Greedy Hospital Scheduler
            </h2>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', margin: 0 }}>
            <strong>Course Outcome:</strong> Problem-class signatures, NP-hard scheduling, and selecting an appropriate advanced algorithm strategy.
          </p>
        </div>

        <button 
          onClick={handleRunAlgorithm}
          className="btn btn-primary" 
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.6rem 1.25rem', fontSize: '0.92rem' }}
        >
          <Play size={18} /> Run Heap Scheduler
        </button>
      </div>

      {/* Meta Specs Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.85rem', marginBottom: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Hospital Use Case</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', marginTop: '0.2rem' }}>
            Prioritize surgeries/patients by Emergency priority, wait time, surgery duration & resources.
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Time Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--primary)', fontWeight: 600, marginTop: '0.2rem' }}>
            Insert: O(log n) | Extract: O(log n) | Peek: O(1)
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Space Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', fontWeight: 600, marginTop: '0.2rem' }}>
            O(n) Binary Heap Array
          </div>
        </div>
      </div>

      {/* Input Data Controls */}
      <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '1rem', marginBottom: '1.5rem', background: '#ffffff' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
          <h4 style={{ fontSize: '0.95rem', margin: 0, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <Database size={16} style={{ color: 'var(--primary)' }} /> Input Dataset ({patientData.length} Cases)
            {isDemoData && <span className="badge badge-warning" style={{ fontSize: '0.65rem' }}>Demo Dataset</span>}
          </h4>

          <button onClick={loadData} className="btn btn-secondary" style={{ padding: '0.25rem 0.6rem', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <RefreshCw size={12} /> Reload Storage Data
          </button>
        </div>

        {/* Quick Add Custom Case Form */}
        <form onSubmit={handleAddCustomPatient} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(140px, 1fr))', gap: '0.6rem', alignItems: 'end' }}>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>Patient Name</label>
            <input 
              type="text" 
              placeholder="e.g. John Doe"
              value={customPatient.name}
              onChange={(e) => setCustomPatient({ ...customPatient, name: e.target.value })}
              style={{ width: '100%', padding: '0.4rem 0.6rem', fontSize: '0.82rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            />
          </div>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>Surgery Type</label>
            <input 
              type="text" 
              placeholder="e.g. Cardiac Surgery"
              value={customPatient.surgeryType}
              onChange={(e) => setCustomPatient({ ...customPatient, surgeryType: e.target.value })}
              style={{ width: '100%', padding: '0.4rem 0.6rem', fontSize: '0.82rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            />
          </div>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>Urgency Priority</label>
            <select
              value={customPatient.priority}
              onChange={(e) => setCustomPatient({ ...customPatient, priority: e.target.value })}
              style={{ width: '100%', padding: '0.4rem 0.6rem', fontSize: '0.82rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            >
              <option value="1">1 - Emergency</option>
              <option value="2">2 - Urgent</option>
              <option value="3">3 - High</option>
              <option value="4">4 - Normal</option>
              <option value="5">5 - Routine</option>
            </select>
          </div>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>Wait Time (Hours)</label>
            <input 
              type="number"
              min="0"
              value={customPatient.waitingHours}
              onChange={(e) => setCustomPatient({ ...customPatient, waitingHours: e.target.value })}
              style={{ width: '100%', padding: '0.4rem 0.6rem', fontSize: '0.82rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            />
          </div>
          <div>
            <button type="submit" className="btn btn-secondary" style={{ width: '100%', padding: '0.45rem', fontSize: '0.82rem', fontWeight: 600 }}>
              + Add Patient Case
            </button>
          </div>
        </form>
      </div>

      {/* Execution Results */}
      {result && (
        <div style={{ marginTop: '1.5rem', animation: 'fadeIn 0.2s ease-in' }}>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#ecfdf5', border: '1px solid #a7f3d0' }}>
              <div style={{ fontSize: '0.75rem', color: '#047857', fontWeight: 600 }}>Total Cases Processed</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#065f46' }}>{result.totalCases}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#eff6ff', border: '1px solid #bfdbfe' }}>
              <div style={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 600 }}>Total Waiting Time</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#1e40af' }}>{result.totalWaitTimeHours} hrs</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#fef3c7', border: '1px solid #fde68a' }}>
              <div style={{ fontSize: '0.75rem', color: '#b45309', fontWeight: 600 }}>Average Waiting Time</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#92400e' }}>{result.avgWaitTimeHours} hrs</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#f3e8ff', border: '1px solid #e9d5ff' }}>
              <div style={{ fontSize: '0.75rem', color: '#6b21a8', fontWeight: 600 }}>Execution Time</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#581c87' }}>{result.executionTimeMs} ms</div>
            </div>
          </div>

          {/* Generated Priority Order Table */}
          <h4 style={{ fontSize: '1rem', color: 'var(--text-main)', marginBottom: '0.75rem' }}>
            📋 Generated Priority Scheduling Order (Binary Heap Priority Queue Output)
          </h4>

          <div style={{ overflowX: 'auto', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem', textAlign: 'left' }}>
              <thead style={{ background: '#f1f5f9', borderBottom: '1px solid #cbd5e1' }}>
                <tr>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Order</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Patient Name</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Surgery Procedure</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Urgency Rank</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Wait Time</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Duration</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Priority Score</th>
                </tr>
              </thead>
              <tbody>
                {result.scheduledList.map((item) => (
                  <tr key={item.scheduleRank} style={{ borderBottom: '1px solid var(--border)', background: item.scheduleRank % 2 === 0 ? '#fafafa' : '#ffffff' }}>
                    <td style={{ padding: '0.6rem 0.8rem', fontWeight: 700, color: 'var(--primary)' }}>
                      #{item.scheduleRank}
                    </td>
                    <td style={{ padding: '0.6rem 0.8rem', fontWeight: 600 }}>{item.name}</td>
                    <td style={{ padding: '0.6rem 0.8rem', color: '#475569' }}>{item.surgeryType}</td>
                    <td style={{ padding: '0.6rem 0.8rem' }}>
                      <span className="badge" style={{ background: item.priorityColor || '#3b82f6', color: '#ffffff', fontSize: '0.68rem', fontWeight: 700 }}>
                        {item.priorityLabel}
                      </span>
                    </td>
                    <td style={{ padding: '0.6rem 0.8rem' }}>{item.waitingHours} hrs</td>
                    <td style={{ padding: '0.6rem 0.8rem' }}>{item.duration} mins</td>
                    <td style={{ padding: '0.6rem 0.8rem', fontWeight: 700, color: '#0f172a' }}>{item.priorityScore}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Theoretical Explanation */}
      <div style={{ marginTop: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', borderLeft: '4px solid var(--primary)', fontSize: '0.85rem' }}>
        <h5 style={{ margin: '0 0 0.4rem', color: 'var(--primary-text)', fontSize: '0.92rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <Info size={16} /> Why Priority Queues are Essential for NP-Hard Hospital Scheduling
        </h5>
        <p style={{ margin: 0, color: '#334155', lineHeight: 1.5 }}>
          Exact multi-resource hospital surgery scheduling with non-preemptive constraints belongs to the class of <strong>NP-hard combinatorial optimization problems</strong>. Because searching for a global exact optimum for N patients across multiple rooms has exponential complexity O(N!), hospital management systems rely on <strong>Priority Queue (Binary Heap) greedy heuristics</strong>. This guarantees that critical emergency procedures are selected in O(log n) time while maintaining high resource utilization.
        </p>
      </div>
    </div>
  );
};

export default CO1PriorityScheduler;
