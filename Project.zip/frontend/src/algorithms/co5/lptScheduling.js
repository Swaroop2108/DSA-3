import MinHeap from './MinHeap';

/**
 * Longest Processing Time (LPT) Approximation Algorithm for Operating Room Scheduling (CO5)
 * 
 * Objective: Minimize Makespan C_max (maximum workload of any OR)
 * Theoretical Bound: C_max / OPT <= (4/3 - 1/(3m)) where m is number of ORs
 */

export const runLPTScheduling = (surgeriesList = [], numORs = 4) => {
  const startTime = performance.now();

  const m = Math.max(1, parseInt(numORs, 10) || 4);

  if (!surgeriesList || surgeriesList.length === 0) {
    return {
      numORs: m,
      totalSurgeries: 0,
      orSchedules: [],
      makespan: 0,
      avgWorkload: 0,
      avgUtilization: 0,
      theoreticalBoundRatio: (4 / 3) - (1 / (3 * m)),
      theoreticalBoundRatioStr: `4/3 - 1/(3*${m}) = ${(4 / 3 - 1 / (3 * m)).toFixed(3)}`,
      optLowerBound: 0,
      executionTimeMs: 0
    };
  }

  // Preprocess surgeries list
  const surgeries = surgeriesList.map((s, idx) => ({
    id: s.id || s.surgeryId || `SURG-${idx + 1}`,
    name: s.surgeryType || s.name || `Surgery Procedure ${idx + 1}`,
    patientName: s.patientName || s.patient || 'Patient',
    duration: Math.max(15, parseInt(s.duration || s.expectedSurgeryDuration || (30 + (idx % 6) * 30), 10)),
    priorityLabel: s.priorityLabel || 'NORMAL'
  }));

  // Step 1: Sort surgeries in descending order of duration - O(n log n)
  surgeries.sort((a, b) => b.duration - a.duration);

  // Step 2: Initialize m Operating Rooms
  const orSchedules = [];
  for (let i = 1; i <= m; i++) {
    orSchedules.push({
      orId: `OR-${String(i).padStart(2, '0')}`,
      name: `Operating Room ${i}`,
      assignedSurgeries: [],
      totalDuration: 0
    });
  }

  // Min-Heap tracking OR workloads - comparator orders by totalDuration ascending
  const minHeap = new MinHeap((a, b) => a.totalDuration - b.totalDuration);

  // Push all empty ORs into Min-Heap
  orSchedules.forEach(room => minHeap.insert(room));

  // Step 3: Assign each surgery to the currently least-loaded OR - O(n log m)
  surgeries.forEach(surgery => {
    // Extract OR with minimum workload
    const leastLoadedOR = minHeap.extract();

    // Assign surgery
    leastLoadedOR.assignedSurgeries.push({
      ...surgery,
      assignedStartMin: leastLoadedOR.totalDuration,
      assignedEndMin: leastLoadedOR.totalDuration + surgery.duration
    });

    leastLoadedOR.totalDuration += surgery.duration;

    // Re-insert updated OR into Min-Heap
    minHeap.insert(leastLoadedOR);
  });

  // Collect final OR states
  const finalORSchedules = [];
  while (!minHeap.isEmpty()) {
    finalORSchedules.push(minHeap.extract());
  }

  // Sort OR schedules by OR ID for clear UI presentation
  finalORSchedules.sort((a, b) => a.orId.localeCompare(b.orId));

  // Calculate Makespan C_max (maximum workload) and metrics
  let makespan = 0;
  let totalDurationSum = 0;
  let maxSingleSurgeryDuration = 0;

  surgeries.forEach(s => {
    totalDurationSum += s.duration;
    if (s.duration > maxSingleSurgeryDuration) maxSingleSurgeryDuration = s.duration;
  });

  finalORSchedules.forEach(or => {
    if (or.totalDuration > makespan) makespan = or.totalDuration;
  });

  const avgWorkload = totalDurationSum / m;
  const avgUtilization = makespan > 0 ? Math.min(100, Math.round((avgWorkload / makespan) * 100)) : 0;

  // Theoretical OPT Lower Bound = max(Average workload, max single surgery duration)
  const optLowerBound = Math.max(Math.ceil(avgWorkload), maxSingleSurgeryDuration);

  // LPT Theoretical Bound Ratio = (4/3 - 1/(3m))
  const theoreticalRatio = (4 / 3) - (1 / (3 * m));
  const maxGuaranteedMakespan = Math.ceil(optLowerBound * theoreticalRatio);

  const endTime = performance.now();
  const executionTimeMs = parseFloat((endTime - startTime).toFixed(3));

  return {
    numORs: m,
    totalSurgeries: surgeries.length,
    orSchedules: finalORSchedules,
    makespan,
    avgWorkload: parseFloat(avgWorkload.toFixed(1)),
    avgUtilization,
    theoreticalBoundRatio: parseFloat(theoreticalRatio.toFixed(3)),
    theoreticalBoundRatioStr: `4/3 - 1/(3*${m}) = ${theoreticalRatio.toFixed(3)}`,
    optLowerBound,
    maxGuaranteedMakespan,
    totalDurationSum,
    executionTimeMs
  };
};
