import React, { useState, useEffect } from 'react';
import { searchHospitalRecordsKMP, buildLPS } from '../../algorithms/co2/kmp';
import { getItem } from '../../services/storage';
import { Play, Search, Code, CheckCircle, Database, Info, Layers } from 'lucide-react';

const CO2KMP = () => {
  const [pattern, setPattern] = useState('cardiac');
  const [targetCategory, setTargetCategory] = useState('ALL');
  const [recordsToSearch, setRecordsToSearch] = useState([]);
  const [result, setResult] = useState(null);
  const [lpsTable, setLpsTable] = useState([]);

  // Load records from localStorage across categories
  const loadData = () => {
    const patients = getItem('medischedule_patients', []);
    const staff = getItem('medischedule_staff', []);
    const equipment = getItem('medischedule_equipment', []);
    const surgeries = getItem('medischedule_surgeries', []);
    const ors = getItem('medischedule_operating_rooms', []);

    let combined = [];

    if (targetCategory === 'ALL' || targetCategory === 'PATIENTS') {
      combined.push(...patients.map(p => ({ category: 'Patient', id: p.patientId, title: p.name, text: `${p.name} ${p.diagnosis} ${p.doctor} ${p.department} ${p.surgeryType}` })));
    }
    if (targetCategory === 'ALL' || targetCategory === 'STAFF') {
      combined.push(...staff.map(s => ({ category: 'Staff', id: s.staffId, title: s.name, text: `${s.name} ${s.role} ${s.department} ${s.specialization}` })));
    }
    if (targetCategory === 'ALL' || targetCategory === 'EQUIPMENT') {
      combined.push(...equipment.map(e => ({ category: 'Equipment', id: e.equipmentId || e.id, title: e.name, text: `${e.name} ${e.category} ${e.location || e.department} ${e.status}` })));
    }
    if (targetCategory === 'ALL' || targetCategory === 'SURGERIES') {
      combined.push(...surgeries.map(su => ({ category: 'Surgery', id: su.surgeryId || su.id, title: su.surgeryType, text: `${su.surgeryType} ${su.patientName} ${su.doctor} ${su.roomName}` })));
    }
    if (targetCategory === 'ALL' || targetCategory === 'ORS') {
      combined.push(...ors.map(o => ({ category: 'Operating Room', id: o.orId, title: o.name, text: `${o.name} ${o.department} ${(o.equipment || []).join(' ')}` })));
    }

    setRecordsToSearch(combined);
  };

  useEffect(() => {
    loadData();
  }, [targetCategory]);

  useEffect(() => {
    if (pattern.trim()) {
      setLpsTable(buildLPS(pattern.trim()));
    } else {
      setLpsTable([]);
    }
  }, [pattern]);

  const handleRunKMP = () => {
    if (!pattern.trim()) return;
    const output = searchHospitalRecordsKMP(recordsToSearch, pattern, targetCategory);
    setResult(output);
  };

  return (
    <div className="card" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
      {/* Module Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.35rem' }}>
            <span className="badge badge-scheduled" style={{ fontSize: '0.75rem', fontWeight: 700 }}>CO2</span>
            <h2 style={{ fontSize: '1.3rem', color: 'var(--primary-text)', margin: 0 }}>
              Knuth-Morris-Pratt (KMP) Record Search Engine
            </h2>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', margin: 0 }}>
            <strong>Course Outcome:</strong> Linear-time string algorithms including KMP and prefix table construction.
          </p>
        </div>

        <button 
          onClick={handleRunKMP}
          className="btn btn-primary" 
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.6rem 1.25rem', fontSize: '0.92rem' }}
        >
          <Play size={18} /> Execute KMP Search
        </button>
      </div>

      {/* Meta Specs Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.85rem', marginBottom: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Hospital Use Case</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', marginTop: '0.2rem' }}>
            Instant search across Patient diagnoses, Staff specializations, Surgery types & Equipment inventory.
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Time Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--primary)', fontWeight: 600, marginTop: '0.2rem' }}>
            Preprocessing: O(m) | Search: O(n) | Total: O(n + m)
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Space Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', fontWeight: 600, marginTop: '0.2rem' }}>
            O(m) for LPS / Pi Array
          </div>
        </div>
      </div>

      {/* Inputs & Quick Presets */}
      <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '1rem', marginBottom: '1.5rem', background: '#ffffff' }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
          <div>
            <label style={{ fontSize: '0.78rem', fontWeight: 600, color: '#475569', display: 'block', marginBottom: '0.3rem' }}>
              Search Pattern (Sub-string)
            </label>
            <div style={{ display: 'flex', gap: '0.5rem' }}>
              <input 
                type="text" 
                value={pattern}
                onChange={(e) => setPattern(e.target.value)}
                placeholder="Enter search pattern..."
                style={{ flex: 1, padding: '0.55rem 0.75rem', fontSize: '0.9rem', borderRadius: 'var(--radius-sm)', border: '1px solid #cbd5e1' }}
              />
            </div>
          </div>

          <div>
            <label style={{ fontSize: '0.78rem', fontWeight: 600, color: '#475569', display: 'block', marginBottom: '0.3rem' }}>
              Target Storage Category
            </label>
            <select
              value={targetCategory}
              onChange={(e) => setTargetCategory(e.target.value)}
              style={{ width: '100%', padding: '0.55rem 0.75rem', fontSize: '0.9rem', borderRadius: 'var(--radius-sm)', border: '1px solid #cbd5e1' }}
            >
              <option value="ALL">All Hospital Records (Combined)</option>
              <option value="PATIENTS">Patients & Diagnoses</option>
              <option value="STAFF">Surgeons & Staff</option>
              <option value="EQUIPMENT">Medical Equipment</option>
              <option value="SURGERIES">Surgeries Schedule</option>
              <option value="ORS">Operating Rooms</option>
            </select>
          </div>
        </div>

        {/* Quick Search Preset Tags */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', flexWrap: 'wrap' }}>
          <span style={{ fontSize: '0.75rem', fontWeight: 600, color: '#64748b' }}>Quick Test Patterns:</span>
          {['cardiac', 'appendectomy', 'desai', 'ventilator', 'icu', 'orthopedics', 'fracture', 'sharma'].map((preset) => (
            <button
              key={preset}
              type="button"
              onClick={() => { setPattern(preset); }}
              style={{
                padding: '0.2rem 0.6rem',
                fontSize: '0.72rem',
                borderRadius: '12px',
                border: pattern === preset ? '1px solid var(--primary)' : '1px solid #cbd5e1',
                background: pattern === preset ? 'var(--primary)' : '#f1f5f9',
                color: pattern === preset ? '#ffffff' : '#334155',
                cursor: 'pointer',
                fontWeight: 600
              }}
            >
              "{preset}"
            </button>
          ))}
        </div>
      </div>

      {/* LPS Table Render */}
      {pattern.trim() && (
        <div style={{ marginBottom: '1.5rem', background: '#f0f9ff', border: '1px solid #bae6fd', padding: '0.85rem', borderRadius: 'var(--radius-sm)' }}>
          <div style={{ fontSize: '0.8rem', fontWeight: 700, color: '#0369a1', marginBottom: '0.5rem' }}>
            ⚡ Computed KMP Longest Prefix Suffix (LPS / Pi) Table for "{pattern}":
          </div>

          <div style={{ display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
            {pattern.split('').map((char, index) => (
              <div key={index} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', background: '#ffffff', border: '1px solid #0284c7', borderRadius: '4px', padding: '0.35rem 0.6rem', minWidth: '36px' }}>
                <span style={{ fontSize: '0.65rem', color: '#64748b', fontWeight: 600 }}>[{index}]</span>
                <span style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--primary)' }}>{char}</span>
                <span style={{ fontSize: '0.8rem', fontWeight: 700, color: '#0369a1', borderTop: '1px solid #e0f2fe', width: '100%', textAlign: 'center', marginTop: '0.2rem' }}>
                  {lpsTable[index] !== undefined ? lpsTable[index] : 0}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Execution Results */}
      {result && (
        <div style={{ marginTop: '1.5rem', animation: 'fadeIn 0.2s ease-in' }}>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: 600 }}>Search Pattern</div>
              <div style={{ fontSize: '1.2rem', fontWeight: 800, color: 'var(--primary)' }}>"{result.pattern}"</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#eff6ff', border: '1px solid #bfdbfe' }}>
              <div style={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 600 }}>Records Searched</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#1e40af' }}>{result.recordsSearched}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#ecfdf5', border: '1px solid #a7f3d0' }}>
              <div style={{ fontSize: '0.75rem', color: '#047857', fontWeight: 600 }}>Matches Found</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#065f46' }}>{result.matchesFound}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#fef3c7', border: '1px solid #fde68a' }}>
              <div style={{ fontSize: '0.75rem', color: '#b45309', fontWeight: 600 }}>Char Comparisons</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#92400e' }}>{result.characterComparisons}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#f3e8ff', border: '1px solid #e9d5ff' }}>
              <div style={{ fontSize: '0.75rem', color: '#6b21a8', fontWeight: 600 }}>Execution Time</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#581c87' }}>{result.executionTimeMs} ms</div>
            </div>
          </div>

          {/* Matches List */}
          <h4 style={{ fontSize: '1rem', color: 'var(--text-main)', marginBottom: '0.75rem' }}>
            🔎 Matching Hospital Records ({result.matchingRecords.length} Items Found)
          </h4>

          {result.matchingRecords.length === 0 ? (
            <div style={{ padding: '1.5rem', textAlign: 'center', background: '#f8fafc', borderRadius: 'var(--radius-sm)', color: '#64748b' }}>
              No matches found for pattern "{pattern}". Try searching for "cardiac", "appendectomy", or "desai".
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              {result.matchingRecords.map((item, idx) => (
                <div key={idx} style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '0.85rem', background: '#ffffff', borderLeft: '4px solid var(--primary)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.4rem' }}>
                    <span className="badge badge-scheduled" style={{ fontSize: '0.68rem' }}>
                      {item.record.category || 'Record'} • {item.record.id}
                    </span>
                    <span style={{ fontSize: '0.75rem', color: '#64748b' }}>{item.record.title}</span>
                  </div>

                  <div style={{ fontSize: '0.85rem', color: '#334155', fontFamily: 'var(--font-mono)', background: '#f8fafc', padding: '0.5rem', borderRadius: '4px', border: '1px solid #e2e8f0' }}>
                    {item.record.text}
                  </div>

                  <div style={{ marginTop: '0.4rem', fontSize: '0.75rem', color: 'var(--primary)', fontWeight: 600 }}>
                    Matches in field(s): {item.matchedFields.map(f => f.field).join(', ')}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Theoretical Explanation */}
      <div style={{ marginTop: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', borderLeft: '4px solid var(--primary)', fontSize: '0.85rem' }}>
        <h5 style={{ margin: '0 0 0.4rem', color: 'var(--primary-text)', fontSize: '0.92rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <Info size={16} /> Knuth-Morris-Pratt (KMP) Linear-Time Guarantees
        </h5>
        <p style={{ margin: 0, color: '#334155', lineHeight: 1.5 }}>
          Unlike naive string matching which incurs O(n × m) comparisons during backtracks, the <strong>KMP algorithm</strong> constructs the <strong>LPS (Longest Prefix Suffix) table</strong> in O(m) time. When a character mismatch occurs, KMP uses the precomputed LPS values to skip redundant comparisons, guaranteeing strict linear time complexity <strong>O(n + m)</strong> across large medical text repositories.
        </p>
      </div>
    </div>
  );
};

export default CO2KMP;
