import React, { useState, useEffect } from 'react';
import { runIntervalDP, formatMinutesToTime, parseTimeToMinutes } from '../../algorithms/co3/intervalDP';
import { getItem } from '../../services/storage';
import { Play, RefreshCw, Calendar, CheckCircle, Database, Info, Clock, Layers } from 'lucide-react';

const CO3IntervalDP = () => {
  const [surgeryData, setSurgeryData] = useState([]);
  const [result, setResult] = useState(null);
  const [isDemoData, setIsDemoData] = useState(false);
  const [customSurgery, setCustomSurgery] = useState({
    name: '',
    patientName: '',
    startTime: '09:00',
    duration: 60,
    priorityValue: 80
  });

  const loadData = () => {
    const localSurgeries = getItem('medischedule_surgeries', []);
    if (localSurgeries && localSurgeries.length > 0) {
      setSurgeryData(localSurgeries);
      setIsDemoData(false);
    } else {
      // Demo dataset with overlapping interval conflicts
      const demoSurgeries = [
        { id: 'S1', name: 'Coronary Bypass', patientName: 'Elena Rostova', startTimeStr: '08:00', startMinutes: 480, endMinutes: 600, duration: 120, weight: 100, priorityLabel: 'EMERGENCY' },
        { id: 'S2', name: 'Emergency Appendectomy', patientName: 'Robert Vance', startTimeStr: '09:00', startMinutes: 540, endMinutes: 630, duration: 90, weight: 90, priorityLabel: 'URGENT' },
        { id: 'S3', name: 'Femur Fracture Fixation', patientName: 'Michael Chang', startTimeStr: '10:00', startMinutes: 600, endMinutes: 720, duration: 120, weight: 80, priorityLabel: 'HIGH' },
        { id: 'S4', name: 'Cholecystectomy', patientName: 'Sophia Patel', startTimeStr: '11:00', startMinutes: 660, endMinutes: 750, duration: 90, weight: 60, priorityLabel: 'MEDIUM' },
        { id: 'S5', name: 'Craniotomy', patientName: 'James Wilson', startTimeStr: '12:00', startMinutes: 720, endMinutes: 870, duration: 150, weight: 100, priorityLabel: 'EMERGENCY' },
        { id: 'S6', name: 'Knee Arthroplasty', patientName: 'Priya Sharma', startTimeStr: '13:30', startMinutes: 810, endMinutes: 930, duration: 120, weight: 70, priorityLabel: 'HIGH' }
      ];
      setSurgeryData(demoSurgeries);
      setIsDemoData(true);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRunAlgorithm = () => {
    const output = runIntervalDP(surgeryData);
    setResult(output);
  };

  const handleAddCustomSurgery = (e) => {
    e.preventDefault();
    if (!customSurgery.name) return;

    const startMin = parseTimeToMinutes(customSurgery.startTime || '09:00');
    const endMin = startMin + parseInt(customSurgery.duration || 60, 10);

    const newCase = {
      id: `SURG-${Date.now().toString().slice(-4)}`,
      name: customSurgery.name,
      patientName: customSurgery.patientName || 'Patient',
      startTimeStr: customSurgery.startTime,
      endTimeStr: formatMinutesToTime(endMin),
      startMinutes: startMin,
      endMinutes: endMin,
      duration: parseInt(customSurgery.duration, 10),
      weight: parseInt(customSurgery.priorityValue, 10),
      priorityLabel: customSurgery.priorityValue >= 90 ? 'EMERGENCY' : customSurgery.priorityValue >= 70 ? 'HIGH' : 'NORMAL'
    };

    setSurgeryData([...surgeryData, newCase]);
    setCustomSurgery({ name: '', patientName: '', startTime: '09:00', duration: 60, priorityValue: 80 });
  };

  return (
    <div className="card" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
      {/* Module Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.35rem' }}>
            <span className="badge badge-scheduled" style={{ fontSize: '0.75rem', fontWeight: 700 }}>CO3</span>
            <h2 style={{ fontSize: '1.3rem', color: 'var(--primary-text)', margin: 0 }}>
              Interval Dynamic Programming Surgery Scheduler
            </h2>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', margin: 0 }}>
            <strong>Course Outcome:</strong> Advanced dynamic programming patterns, specifically weighted interval DP.
          </p>
        </div>

        <button 
          onClick={handleRunAlgorithm}
          className="btn btn-primary" 
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.6rem 1.25rem', fontSize: '0.92rem' }}
        >
          <Play size={18} /> Solve Interval DP
        </button>
      </div>

      {/* Meta Specs Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.85rem', marginBottom: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Hospital Use Case</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', marginTop: '0.2rem' }}>
            Optimal non-overlapping surgery schedule maximizing priority value without time conflicts.
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Time Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--primary)', fontWeight: 600, marginTop: '0.2rem' }}>
            Sorting: O(n log n) | Predecessor Binary Search: O(n log n) | DP: O(n)
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Space Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', fontWeight: 600, marginTop: '0.2rem' }}>
            O(n) DP Table & Choices
          </div>
        </div>
      </div>

      {/* Input Data Controls */}
      <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '1rem', marginBottom: '1.5rem', background: '#ffffff' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' }}>
          <h4 style={{ fontSize: '0.95rem', margin: 0, display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
            <Database size={16} style={{ color: 'var(--primary)' }} /> Candidate Surgery Intervals ({surgeryData.length} Cases)
            {isDemoData && <span className="badge badge-warning" style={{ fontSize: '0.65rem' }}>Demo Dataset</span>}
          </h4>

          <button onClick={loadData} className="btn btn-secondary" style={{ padding: '0.25rem 0.6rem', fontSize: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}>
            <RefreshCw size={12} /> Reload Storage Data
          </button>
        </div>

        {/* Add Custom Surgery Interval */}
        <form onSubmit={handleAddCustomSurgery} style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '0.6rem', alignItems: 'end' }}>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>Surgery Name</label>
            <input 
              type="text" 
              placeholder="e.g. Spine Surgery"
              value={customSurgery.name}
              onChange={(e) => setCustomSurgery({ ...customSurgery, name: e.target.value })}
              style={{ width: '100%', padding: '0.4rem 0.6rem', fontSize: '0.82rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            />
          </div>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>Start Time</label>
            <input 
              type="time" 
              value={customSurgery.startTime}
              onChange={(e) => setCustomSurgery({ ...customSurgery, startTime: e.target.value })}
              style={{ width: '100%', padding: '0.4rem 0.6rem', fontSize: '0.82rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            />
          </div>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>Duration (Mins)</label>
            <input 
              type="number"
              min="15"
              step="15"
              value={customSurgery.duration}
              onChange={(e) => setCustomSurgery({ ...customSurgery, duration: e.target.value })}
              style={{ width: '100%', padding: '0.4rem 0.6rem', fontSize: '0.82rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            />
          </div>
          <div>
            <label style={{ fontSize: '0.75rem', fontWeight: 600, color: '#475569' }}>Priority Value (Weight)</label>
            <input 
              type="number"
              min="10"
              max="200"
              value={customSurgery.priorityValue}
              onChange={(e) => setCustomSurgery({ ...customSurgery, priorityValue: e.target.value })}
              style={{ width: '100%', padding: '0.4rem 0.6rem', fontSize: '0.82rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}
            />
          </div>
          <div>
            <button type="submit" className="btn btn-secondary" style={{ width: '100%', padding: '0.45rem', fontSize: '0.82rem', fontWeight: 600 }}>
              + Add Interval Case
            </button>
          </div>
        </form>
      </div>

      {/* Execution Results */}
      {result && (
        <div style={{ marginTop: '1.5rem', animation: 'fadeIn 0.2s ease-in' }}>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: 600 }}>Candidate Surgeries</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0f172a' }}>{result.availableSurgeriesCount}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#ecfdf5', border: '1px solid #a7f3d0' }}>
              <div style={{ fontSize: '0.75rem', color: '#047857', fontWeight: 600 }}>Max Compatible Value</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#065f46' }}>{result.maxCompatiblePriority} pts</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#eff6ff', border: '1px solid #bfdbfe' }}>
              <div style={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 600 }}>Selected Surgeries</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#1e40af' }}>{result.selectedSurgeries.length}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#fef3c7', border: '1px solid #fde68a' }}>
              <div style={{ fontSize: '0.75rem', color: '#b45309', fontWeight: 600 }}>Conflicts Avoided</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#92400e' }}>{result.conflictsAvoided}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#f3e8ff', border: '1px solid #e9d5ff' }}>
              <div style={{ fontSize: '0.75rem', color: '#6b21a8', fontWeight: 600 }}>Execution Time</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#581c87' }}>{result.executionTimeMs} ms</div>
            </div>
          </div>

          {/* Selected Optimal Surgeries Timeline */}
          <h4 style={{ fontSize: '1rem', color: 'var(--text-main)', marginBottom: '0.75rem' }}>
            ✅ Optimal Non-Overlapping Schedule (Selected via DP Backtracking)
          </h4>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.6rem', marginBottom: '1.5rem' }}>
            {result.selectedSurgeries.map((s, idx) => (
              <div key={idx} style={{ border: '1px solid #a7f3d0', borderRadius: 'var(--radius-sm)', padding: '0.85rem', background: '#f0fdf4', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '0.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <div style={{ width: '32px', height: '32px', borderRadius: '50%', background: '#10b981', color: '#ffffff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: '0.9rem' }}>
                    {idx + 1}
                  </div>
                  <div>
                    <div style={{ fontWeight: 700, fontSize: '0.92rem', color: '#065f46' }}>{s.name}</div>
                    <div style={{ fontSize: '0.78rem', color: '#047857' }}>Patient: {s.patientName} • Surgeon: {s.doctor}</div>
                  </div>
                </div>

                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
                  <div style={{ fontSize: '0.85rem', fontWeight: 700, color: '#0f172a', background: '#ffffff', padding: '0.3rem 0.6rem', borderRadius: '4px', border: '1px solid #cbd5e1' }}>
                    🕒 {s.startTimeStr} - {s.endTimeStr}
                  </div>
                  <span className="badge badge-scheduled" style={{ fontSize: '0.72rem', fontWeight: 700 }}>
                    Weight: {s.weight} pts
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Dynamic Programming State Table */}
          <h4 style={{ fontSize: '1rem', color: 'var(--text-main)', marginBottom: '0.75rem' }}>
            📊 Interval DP State Calculation Table
          </h4>

          <div style={{ overflowX: 'auto', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.85rem', textAlign: 'left' }}>
              <thead style={{ background: '#f1f5f9', borderBottom: '1px solid #cbd5e1' }}>
                <tr>
                  <th style={{ padding: '0.6rem 0.8rem' }}>i</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Surgery Name</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Time Window</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Weight (w_i)</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Predecessor p(i)</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>DP[i] Value</th>
                  <th style={{ padding: '0.6rem 0.8rem' }}>Decision</th>
                </tr>
              </thead>
              <tbody>
                {result.dpTable.map((row) => (
                  <tr key={row.index} style={{ borderBottom: '1px solid var(--border)', background: row.decision === 'INCLUDE' ? '#ecfdf5' : '#ffffff' }}>
                    <td style={{ padding: '0.6rem 0.8rem', fontWeight: 700 }}>{row.index}</td>
                    <td style={{ padding: '0.6rem 0.8rem', fontWeight: 600 }}>{row.surgeryName}</td>
                    <td style={{ padding: '0.6rem 0.8rem', color: '#475569' }}>{row.timeWindow}</td>
                    <td style={{ padding: '0.6rem 0.8rem', fontWeight: 700, color: 'var(--primary)' }}>{row.weight}</td>
                    <td style={{ padding: '0.6rem 0.8rem' }}>
                      {row.predecessorIndex > 0 ? `Item #${row.predecessorIndex} (${row.predecessorName})` : '0 (None)'}
                    </td>
                    <td style={{ padding: '0.6rem 0.8rem', fontWeight: 800, color: '#0f172a' }}>{row.dpValue}</td>
                    <td style={{ padding: '0.6rem 0.8rem' }}>
                      <span className={`badge ${row.decision === 'INCLUDE' ? 'badge-completed' : 'badge-scheduled'}`} style={{ fontSize: '0.68rem', fontWeight: 700 }}>
                        {row.decision}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Theoretical Explanation */}
      <div style={{ marginTop: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', borderLeft: '4px solid var(--primary)', fontSize: '0.85rem' }}>
        <h5 style={{ margin: '0 0 0.4rem', color: 'var(--primary-text)', fontSize: '0.92rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <Info size={16} /> Weighted Interval DP State Recurrence Formula
        </h5>
        <p style={{ margin: 0, color: '#334155', lineHeight: 1.5 }}>
          Given n surgeries sorted by finishing time, let p(i) be the largest index j &lt; i such that surgery j is non-overlapping with surgery i. The DP recurrence equation is:
          <br />
          <strong>DP[i] = max(DP[i-1], weight_i + DP[p(i)])</strong>
          <br />
          This guarantees finding the global maximum priority schedule in O(n log n) time.
        </p>
      </div>
    </div>
  );
};

export default CO3IntervalDP;
