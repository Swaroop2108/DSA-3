/**
 * Web Worker inline code string for Parallel Prefix Sum & Reduce
 */
export const workerCode = `
self.onmessage = function(e) {
  const { action, chunk, offset = 0 } = e.data;
  
  if (action === 'PREFIX_SUM') {
    const len = chunk.length;
    const prefix = new Float64Array(len);
    let currentSum = 0;
    
    for (let i = 0; i < len; i++) {
      currentSum += chunk[i];
      prefix[i] = currentSum + offset;
    }
    
    const totalSum = currentSum;
    self.postMessage({ prefix: Array.from(prefix), totalSum });
  } else if (action === 'REDUCE_SUM') {
    let sum = 0;
    for (let i = 0; i < chunk.length; i++) {
      sum += chunk[i];
    }
    self.postMessage({ sum });
  }
};
`;
