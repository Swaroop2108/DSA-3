/**
 * Knuth-Morris-Pratt (KMP) String Matching Algorithm Implementation
 * Linear-time string matching without native String.includes() or regex.
 */

/**
 * Builds the Longest Prefix Suffix (LPS) / Pi table for KMP.
 * Time Complexity: O(m) where m = pattern length
 * Space Complexity: O(m)
 */
export const buildLPS = (pattern) => {
  const m = pattern.length;
  const lps = new Array(m).fill(0);
  let len = 0; // length of previous longest prefix suffix
  let i = 1;

  while (i < m) {
    if (pattern[i].toLowerCase() === pattern[len].toLowerCase()) {
      len++;
      lps[i] = len;
      i++;
    } else {
      if (len !== 0) {
        len = lps[len - 1];
      } else {
        lps[i] = 0;
        i++;
      }
    }
  }

  return lps;
};

/**
 * Searches for all occurrences of pattern in text using KMP.
 * Time Complexity: O(n) where n = text length
 * Space Complexity: O(m) for LPS table
 * 
 * Returns { matches: indexArray, characterComparisons, lps }
 */
export const kmpSearch = (text, pattern) => {
  if (!pattern || !text) {
    return { matches: [], characterComparisons: 0, lps: [] };
  }

  const n = text.length;
  const m = pattern.length;
  if (m > n) {
    return { matches: [], characterComparisons: 0, lps: buildLPS(pattern) };
  }

  const lps = buildLPS(pattern);
  const matches = [];
  let comparisons = 0;

  let i = 0; // index for text
  let j = 0; // index for pattern

  while (i < n) {
    comparisons++;
    if (pattern[j].toLowerCase() === text[i].toLowerCase()) {
      i++;
      j++;
    }

    if (j === m) {
      matches.push(i - j); // match found at index i - j
      j = lps[j - 1];
    } else if (i < n && pattern[j].toLowerCase() !== text[i].toLowerCase()) {
      if (j !== 0) {
        j = lps[j - 1];
      } else {
        i++;
      }
    }
  }

  return {
    matches,
    characterComparisons: comparisons,
    lps
  };
};

/**
 * Searches across a list of hospital record objects using KMP algorithm.
 * Inspects all string fields of each record.
 */
export const searchHospitalRecordsKMP = (records = [], pattern = '', categoryName = 'Hospital Records') => {
  const startTime = performance.now();

  if (!pattern || pattern.trim() === '') {
    return {
      pattern: '',
      recordsSearched: records.length,
      matchesFound: 0,
      matchingRecords: [],
      lps: [],
      characterComparisons: 0,
      executionTimeMs: 0
    };
  }

  const trimmedPattern = pattern.trim();
  const lps = buildLPS(trimmedPattern);

  let totalComparisons = 0;
  const matchingRecords = [];

  records.forEach((record, recordIndex) => {
    let isRecordMatched = false;
    const matchedFields = [];

    // Search through object string fields
    Object.keys(record).forEach((key) => {
      const val = record[key];
      if (val !== null && val !== undefined) {
        const textVal = Array.isArray(val) ? val.join(' ') : String(val);
        const result = kmpSearch(textVal, trimmedPattern);
        totalComparisons += result.characterComparisons;

        if (result.matches.length > 0) {
          isRecordMatched = true;
          matchedFields.push({
            field: key,
            valText: textVal,
            matchIndices: result.matches
          });
        }
      }
    });

    if (isRecordMatched) {
      matchingRecords.push({
        recordIndex,
        record,
        matchedFields
      });
    }
  });

  const endTime = performance.now();
  const executionTimeMs = parseFloat((endTime - startTime).toFixed(3));

  return {
    pattern: trimmedPattern,
    recordsSearched: records.length,
    matchesFound: matchingRecords.length,
    matchingRecords,
    lps,
    characterComparisons: totalComparisons,
    executionTimeMs
  };
};
