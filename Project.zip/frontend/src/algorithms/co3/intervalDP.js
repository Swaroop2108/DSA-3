/**
 * Weighted Interval Scheduling using Dynamic Programming (CO3)
 * Maximizes total surgery priority value without overlapping OR time slots.
 */

// Helper to convert time string "HH:MM" or ISO string to minutes from midnight
export const parseTimeToMinutes = (timeStr) => {
  if (typeof timeStr === 'number') return timeStr;
  if (!timeStr) return 0;
  
  if (timeStr.includes('T')) {
    const d = new Date(timeStr);
    return d.getHours() * 60 + d.getMinutes();
  }

  const parts = timeStr.split(':');
  if (parts.length >= 2) {
    const hours = parseInt(parts[0], 10);
    const mins = parseInt(parts[1], 10);
    return hours * 60 + mins;
  }
  return 0;
};

export const formatMinutesToTime = (minutes) => {
  const h = Math.floor(minutes / 60) % 24;
  const m = Math.floor(minutes % 60);
  const pad = (n) => String(n).padStart(2, '0');
  return `${pad(h)}:${pad(m)}`;
};

/**
 * Binary search to find the latest non-overlapping predecessor index p(i).
 * Returns 1-based index (0 if no predecessor exists).
 */
const findPredecessorBinarySearch = (surgeries, i) => {
  let low = 0;
  let high = i - 1;
  let result = -1;

  const currentStart = surgeries[i].startMinutes;

  while (low <= high) {
    const mid = Math.floor((low + high) / 2);
    if (surgeries[mid].endMinutes <= currentStart) {
      result = mid;
      low = mid + 1; // Try to find a later compatible predecessor
    } else {
      high = mid - 1;
    }
  }

  return result; // -1 if none found, else index in 0-indexed array
};

export const runIntervalDP = (surgeryList = []) => {
  const startTime = performance.now();

  if (!surgeryList || surgeryList.length === 0) {
    return {
      availableSurgeriesCount: 0,
      maxCompatiblePriority: 0,
      selectedSurgeries: [],
      dpTable: [],
      conflictsAvoided: 0,
      executionTimeMs: 0
    };
  }

  // Preprocess input items
  const items = surgeryList.map((s, idx) => {
    let startMin = s.startMinutes ?? parseTimeToMinutes(s.startTime || s.scheduledTime || '09:00');
    let endMin = s.endMinutes ?? (s.endTime ? parseTimeToMinutes(s.endTime) : startMin + (s.duration || s.expectedSurgeryDuration || 60));

    // Handle overnight edge cases or invalid durations
    if (endMin <= startMin) endMin = startMin + 60;

    // Weight/value: Emergency = 100, High = 80, Medium = 60, Normal = 40, Routine = 20
    const priorityVal = s.value || s.priorityValue || (
      s.priority === 1 || s.priorityLabel === 'EMERGENCY' ? 100 :
      s.priority === 2 || s.priorityLabel === 'URGENT' ? 85 :
      s.priority === 3 || s.priorityLabel === 'HIGH' ? 70 :
      s.priority === 4 || s.priorityLabel === 'MEDIUM' ? 50 : 30
    );

    return {
      originalId: s.id || s.surgeryId || `SURG-${idx + 1}`,
      name: s.surgeryType || s.name || s.title || `Surgery ${idx + 1}`,
      patientName: s.patientName || s.patient || 'Patient Case',
      doctor: s.doctor || s.assignedDoctor || 'Lead Surgeon',
      room: s.orId || s.roomName || 'Operating Room',
      startTimeStr: s.startTimeStr || formatMinutesToTime(startMin),
      endTimeStr: s.endTimeStr || formatMinutesToTime(endMin),
      startMinutes: startMin,
      endMinutes: endMin,
      weight: priorityVal,
      priorityLabel: s.priorityLabel || (priorityVal >= 100 ? 'EMERGENCY' : priorityVal >= 70 ? 'HIGH' : 'NORMAL')
    };
  });

  // Step 1: Sort surgeries by end time - O(n log n)
  items.sort((a, b) => a.endMinutes - b.endMinutes);

  const n = items.length;
  // 1-based DP table
  const dp = new Array(n + 1).fill(0);
  const p = new Array(n + 1).fill(0); // Predecessor 1-based index
  const choice = new Array(n + 1).fill(false); // Whether item i was selected in DP[i]

  const dpTableDetails = [];

  // Step 2 & 3: Fill DP table and Predecessors
  for (let i = 1; i <= n; i++) {
    const current = items[i - 1];
    const predIdx = findPredecessorBinarySearch(items, i - 1);
    p[i] = predIdx + 1; // 1-based index (0 means no predecessor)

    const includeWeight = current.weight + (p[i] > 0 ? dp[p[i]] : 0);
    const excludeWeight = dp[i - 1];

    if (includeWeight > excludeWeight) {
      dp[i] = includeWeight;
      choice[i] = true;
    } else {
      dp[i] = excludeWeight;
      choice[i] = false;
    }

    dpTableDetails.push({
      index: i,
      surgeryName: current.name,
      patientName: current.patientName,
      timeWindow: `${current.startTimeStr} - ${current.endTimeStr}`,
      weight: current.weight,
      predecessorIndex: p[i],
      predecessorName: p[i] > 0 ? items[p[i] - 1].name : 'None',
      dpValue: dp[i],
      decision: choice[i] ? 'INCLUDE' : 'EXCLUDE'
    });
  }

  // Step 4: Reconstruct optimal solution by backtracking DP choices
  const selectedSurgeries = [];
  let curr = n;
  while (curr > 0) {
    if (choice[curr]) {
      selectedSurgeries.push(items[curr - 1]);
      curr = p[curr]; // Jump to predecessor
    } else {
      curr = curr - 1;
    }
  }

  selectedSurgeries.reverse(); // Order chronologically

  // Count conflicts avoided
  const conflictsAvoided = n - selectedSurgeries.length;

  const endTime = performance.now();
  const executionTimeMs = parseFloat((endTime - startTime).toFixed(3));

  return {
    availableSurgeriesCount: n,
    maxCompatiblePriority: dp[n],
    selectedSurgeries,
    dpTable: dpTableDetails,
    conflictsAvoided,
    executionTimeMs
  };
};
