import PriorityQueue from './PriorityQueue';

/**
 * Priority Queue Greedy Scheduler for Hospital Patient & Surgery Prioritization
 * 
 * Score Calculation Heuristic:
 * Priority Value = (Emergency Base Weight) * 50 + (Waiting Hours) * 2 - (Surgery Duration Mins) * 0.1
 * 
 * Where Emergency Base Weights are:
 * Emergency: Priority 1 (Weight 10)
 * Urgent: Priority 2 (Weight 8)
 * High: Priority 3 (Weight 6)
 * Normal: Priority 4 (Weight 4)
 * Routine: Priority 5 (Weight 2)
 */

export const PRIORITY_MAP = {
  1: { label: 'EMERGENCY', weight: 100, color: '#ef4444' },
  2: { label: 'URGENT', weight: 80, color: '#f97316' },
  3: { label: 'HIGH', weight: 60, color: '#eab308' },
  4: { label: 'NORMAL', weight: 40, color: '#3b82f6' },
  5: { label: 'ROUTINE', weight: 20, color: '#64748b' }
};

export const runPriorityScheduler = (patientList = []) => {
  const startTime = performance.now();

  if (!patientList || patientList.length === 0) {
    return {
      scheduledList: [],
      totalCases: 0,
      totalWaitTimeHours: 0,
      avgWaitTimeHours: 0,
      executionTimeMs: 0,
      heapSteps: []
    };
  }

  // Calculate waiting time and priority score for each patient
  const processedItems = patientList.map((p, index) => {
    const priorityLevel = p.priority || (p.priorityLabel === 'EMERGENCY' ? 1 : p.priorityLabel === 'HIGH' ? 3 : 4);
    const admissionTime = p.admissionDate ? new Date(p.admissionDate).getTime() : Date.now() - (index * 3600000 * 4);
    const waitingHours = Math.max(0, Math.round((Date.now() - admissionTime) / 3600000));
    const duration = p.expectedSurgeryDuration || p.duration || 60;

    // Higher calculated score means HIGHER urgency
    const priorityInfo = PRIORITY_MAP[priorityLevel] || PRIORITY_MAP[4];
    const priorityScore = (priorityInfo.weight * 10) + (waitingHours * 2) - (duration * 0.05);

    return {
      ...p,
      id: p.patientId || p.id || `PAT-${index + 1}`,
      name: p.name || `Patient ${index + 1}`,
      surgeryType: p.surgeryType || p.diagnosis || 'General Surgical Procedure',
      priorityLevel,
      priorityLabel: priorityInfo.label,
      priorityColor: priorityInfo.color,
      waitingHours,
      duration,
      priorityScore: parseFloat(priorityScore.toFixed(2))
    };
  });

  // Create PriorityQueue instance (Max-heap based on priorityScore)
  const pq = new PriorityQueue((a, b) => b.priorityScore - a.priorityScore);

  const heapSteps = [];

  // Step 1: Insert all patients into Binary Heap
  processedItems.forEach((patient, idx) => {
    pq.insert(patient);
    heapSteps.push({
      action: 'INSERT',
      patient: patient.name,
      priorityLabel: patient.priorityLabel,
      priorityScore: patient.priorityScore,
      heapSize: pq.size()
    });
  });

  // Step 2: Extract in priority order
  const scheduledList = [];
  let currentAccumulatedWaitTime = 0;
  let totalWaitTimeHours = 0;

  while (!pq.isEmpty()) {
    const top = pq.extract();
    currentAccumulatedWaitTime += top.waitingHours;
    totalWaitTimeHours += top.waitingHours;

    scheduledList.push({
      scheduleRank: scheduledList.length + 1,
      ...top,
      accumulatedWaitTimeHours: currentAccumulatedWaitTime
    });

    heapSteps.push({
      action: 'EXTRACT_MAX',
      patient: top.name,
      priorityLabel: top.priorityLabel,
      priorityScore: top.priorityScore,
      heapSizeRemaining: pq.size()
    });
  }

  const endTime = performance.now();
  const executionTimeMs = parseFloat((endTime - startTime).toFixed(3));

  const avgWaitTimeHours = scheduledList.length > 0 
    ? parseFloat((totalWaitTimeHours / scheduledList.length).toFixed(1)) 
    : 0;

  return {
    scheduledList,
    totalCases: scheduledList.length,
    totalWaitTimeHours,
    avgWaitTimeHours,
    executionTimeMs,
    heapSteps
  };
};
