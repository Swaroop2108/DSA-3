import React, { useState } from 'react';
import CO1PriorityScheduler from '../components/dsa/CO1PriorityScheduler';
import CO2KMP from '../components/dsa/CO2KMP';
import CO3IntervalDP from '../components/dsa/CO3IntervalDP';
import CO4MaxFlow from '../components/dsa/CO4MaxFlow';
import CO5Approximation from '../components/dsa/CO5Approximation';
import CO6RandomizedParallel from '../components/dsa/CO6RandomizedParallel';

import { Cpu, CheckCircle, Layers, BookOpen, ShieldCheck, Zap } from 'lucide-react';

const DSAAlgorithmCenter = () => {
  const [activeTab, setActiveTab] = useState('CO1');

  const coModules = [
    { id: 'CO1', label: 'CO1 — Priority Queue', shortDesc: 'Greedy Patient Prioritization', component: CO1PriorityScheduler },
    { id: 'CO2', label: 'CO2 — KMP Search', shortDesc: 'Linear-Time Record Search', component: CO2KMP },
    { id: 'CO3', label: 'CO3 — Interval DP', shortDesc: 'Optimal Surgery Scheduling', component: CO3IntervalDP },
    { id: 'CO4', label: 'CO4 — Edmonds-Karp', shortDesc: 'Max Flow Resource Allocation', component: CO4MaxFlow },
    { id: 'CO5', label: 'CO5 — Approximation', shortDesc: 'LPT Parallel OR Scheduling', component: CO5Approximation },
    { id: 'CO6', label: 'CO6 — Monte Carlo & Parallel', shortDesc: 'Simulations & Parallel Primitives', component: CO6RandomizedParallel }
  ];

  const ActiveComponent = coModules.find(m => m.id === activeTab)?.component || CO1PriorityScheduler;

  const coSummaryTable = [
    { co: 'CO1', algorithm: 'Priority Queue (Binary Heap) + Greedy', input: 'Unordered patient cases with urgency ranks', output: 'Prioritized scheduling order & waiting times', timeComp: 'O(n log n)', spaceComp: 'O(n)', app: 'Hospital patient waiting list & surgery prioritization' },
    { co: 'CO2', algorithm: 'Knuth-Morris-Pratt (KMP) String Match', input: 'Search pattern & target hospital records', output: 'Matching records, LPS table, comparisons count', timeComp: 'O(n + m)', spaceComp: 'O(m)', app: 'Fast linear-time search across patients, staff & equipment' },
    { co: 'CO3', algorithm: 'Weighted Interval Dynamic Programming', input: 'Candidate surgeries with time slots & weights', output: 'Optimal non-overlapping schedule & DP table', timeComp: 'O(n log n)', spaceComp: 'O(n)', app: 'Operating Room non-overlapping surgery slot optimization' },
    { co: 'CO4', algorithm: 'Edmonds-Karp Maximum Flow (BFS)', input: 'Source-to-Sink hospital flow network', output: 'Max Flow value, augmenting paths, Min-Cut bottlenecks', timeComp: 'O(V * E²)', spaceComp: 'O(V + E)', app: 'Multi-resource hospital capacity allocation & bottleneck detection' },
    { co: 'CO5', algorithm: 'LPT Approximation Algorithm (Min-Heap)', input: 'Number of ORs (m) & surgeries sorted by duration', output: 'Balanced OR workloads, makespan C_max, ratio bound', timeComp: 'O(n log n + n log m)', spaceComp: 'O(n + m)', app: 'Multi-OR load balancing with provable worst-case ratio bounds' },
    { co: 'CO6', algorithm: 'Monte Carlo + Parallel Prefix Sum/Reduce', input: 'Stochastic duration bounds & analytics datasets', output: 'Delay probabilities, OR overload %, parallel speedup', timeComp: 'O(N*S) / O(n/p + log p)', spaceComp: 'O(n)', app: 'Surgery duration uncertainty simulation & big data analytics' }
  ];

  return (
    <div className="page-wrapper" style={{ padding: '1.5rem 2rem' }}>
      {/* Page Header */}
      <div className="page-header" style={{ marginBottom: '1.5rem' }}>
        <div>
          <h1 className="page-title" style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', fontSize: '1.6rem', color: 'var(--primary-text)' }}>
            <Cpu size={32} style={{ color: 'var(--primary)' }} /> DSA Algorithm Center
          </h1>
          <p className="page-subtitle" style={{ color: 'var(--text-muted)', fontSize: '0.92rem', marginTop: '0.2rem' }}>
            Real executable DSA-3 algorithm implementations covering all six Course Outcomes (CO1 — CO6).
          </p>
        </div>
      </div>

      {/* CO COVERAGE DASHBOARD */}
      <div className="card" style={{ padding: '1.25rem', marginBottom: '2rem', border: '1px solid var(--border)', background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem', marginBottom: '1rem' }}>
          <div>
            <h2 style={{ fontSize: '1.15rem', color: 'var(--text-main)', margin: 0, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <ShieldCheck size={22} style={{ color: '#10b981' }} /> DSA-3 CO Coverage
            </h2>
            <span style={{ fontSize: '0.8rem', color: '#64748b' }}>
              Click any Course Outcome card below to launch its live executable algorithm.
            </span>
          </div>

          <div style={{ display: 'flex', gap: '1rem' }}>
            <div style={{ background: '#ecfdf5', border: '1px solid #a7f3d0', padding: '0.5rem 0.85rem', borderRadius: 'var(--radius-sm)', textAlign: 'center' }}>
              <span style={{ fontSize: '0.7rem', color: '#047857', textTransform: 'uppercase', fontWeight: 700 }}>Algorithms Implemented</span>
              <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#065f46' }}>6 / 6</div>
            </div>
            <div style={{ background: '#eff6ff', border: '1px solid #bfdbfe', padding: '0.5rem 0.85rem', borderRadius: 'var(--radius-sm)', textAlign: 'center' }}>
              <span style={{ fontSize: '0.7rem', color: '#1d4ed8', textTransform: 'uppercase', fontWeight: 700 }}>Course Outcomes Covered</span>
              <div style={{ fontSize: '1.25rem', fontWeight: 800, color: '#1e40af' }}>6 / 6</div>
            </div>
          </div>
        </div>

        {/* 6 Status Cards */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(170px, 1fr))', gap: '0.75rem' }}>
          {coModules.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <div
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                style={{
                  border: isActive ? '2px solid var(--primary)' : '1px solid var(--border)',
                  borderRadius: 'var(--radius-sm)',
                  padding: '0.85rem 0.75rem',
                  background: isActive ? '#eff6ff' : '#ffffff',
                  cursor: 'pointer',
                  transition: 'all 0.15s ease',
                  boxShadow: isActive ? '0 4px 12px rgba(13, 148, 136, 0.15)' : 'none'
                }}
              >
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.3rem' }}>
                  <span style={{ fontSize: '0.82rem', fontWeight: 800, color: isActive ? 'var(--primary)' : 'var(--primary-text)' }}>
                    {item.id}
                  </span>
                  <span style={{ fontSize: '0.72rem', color: '#10b981', fontWeight: 700, display: 'flex', alignItems: 'center', gap: '0.2rem' }}>
                    <CheckCircle size={13} /> Implemented
                  </span>
                </div>
                <div style={{ fontSize: '0.75rem', color: '#475569', fontWeight: 600, lineHeight: 1.2 }}>
                  {item.shortDesc}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* TABS NAVIGATION */}
      <div style={{ display: 'flex', gap: '0.4rem', borderBottom: '2px solid var(--border)', marginBottom: '1.5rem', overflowX: 'auto', paddingBottom: '2px' }}>
        {coModules.map((mod) => {
          const isActive = activeTab === mod.id;
          return (
            <button
              key={mod.id}
              onClick={() => setActiveTab(mod.id)}
              style={{
                padding: '0.65rem 1.1rem',
                fontSize: '0.88rem',
                fontWeight: isActive ? 700 : 500,
                color: isActive ? 'var(--primary)' : '#64748b',
                background: 'transparent',
                border: 'none',
                borderBottom: isActive ? '3px solid var(--primary)' : '3px solid transparent',
                cursor: 'pointer',
                whiteSpace: 'nowrap',
                transition: 'all 0.15s ease'
              }}
            >
              {mod.label}
            </button>
          );
        })}
      </div>

      {/* ACTIVE ALGORITHM MODULE COMPONENT */}
      <ActiveComponent />

      {/* DOCUMENTATION SECTION: WHY THESE ALGORITHMS FIT MEDISCHEDULE */}
      <div className="card" style={{ padding: '1.5rem', marginTop: '2rem', borderTop: '4px solid var(--primary)' }}>
        <h3 style={{ fontSize: '1.2rem', color: 'var(--primary-text)', margin: '0 0 0.5rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <BookOpen size={22} style={{ color: 'var(--primary)' }} /> Why These Algorithms Fit MediSchedule
        </h3>
        <p style={{ fontSize: '0.88rem', color: 'var(--text-muted)', marginBottom: '1.25rem' }}>
          Comprehensive architectural mapping of DSA-3 course outcomes to real hospital resource management requirements.
        </p>

        <div style={{ overflowX: 'auto', border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '0.82rem', textAlign: 'left' }}>
            <thead style={{ background: '#f1f5f9', borderBottom: '1px solid #cbd5e1' }}>
              <tr>
                <th style={{ padding: '0.65rem 0.8rem' }}>CO</th>
                <th style={{ padding: '0.65rem 0.8rem' }}>Algorithm Strategy</th>
                <th style={{ padding: '0.65rem 0.8rem' }}>Input Format</th>
                <th style={{ padding: '0.65rem 0.8rem' }}>Output Results</th>
                <th style={{ padding: '0.65rem 0.8rem' }}>Time Complexity</th>
                <th style={{ padding: '0.65rem 0.8rem' }}>Space</th>
                <th style={{ padding: '0.65rem 0.8rem' }}>Hospital Application</th>
              </tr>
            </thead>
            <tbody>
              {coSummaryTable.map((row, idx) => (
                <tr key={row.co} style={{ borderBottom: '1px solid var(--border)', background: idx % 2 === 0 ? '#fafafa' : '#ffffff' }}>
                  <td style={{ padding: '0.65rem 0.8rem', fontWeight: 800, color: 'var(--primary)' }}>{row.co}</td>
                  <td style={{ padding: '0.65rem 0.8rem', fontWeight: 600 }}>{row.algorithm}</td>
                  <td style={{ padding: '0.65rem 0.8rem', color: '#475569' }}>{row.input}</td>
                  <td style={{ padding: '0.65rem 0.8rem', color: '#475569' }}>{row.output}</td>
                  <td style={{ padding: '0.65rem 0.8rem', fontWeight: 700, color: 'var(--primary)' }}>{row.timeComp}</td>
                  <td style={{ padding: '0.65rem 0.8rem' }}>{row.spaceComp}</td>
                  <td style={{ padding: '0.65rem 0.8rem', color: '#334155' }}>{row.app}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DSAAlgorithmCenter;
