/**
 * Monte Carlo Simulation for Hospital Surgery Scheduling Uncertainty (CO6-A)
 * Generates stochastic duration samples for surgeries to estimate schedule delay probabilities.
 */

export const runMonteCarloSimulation = (surgeriesList = [], iterations = 1000, maxCapacityMins = 480) => {
  const startTime = performance.now();
  const numSimulations = Math.max(10, parseInt(iterations, 10) || 1000);

  // Prepare surgery baseline estimates if empty
  const baseSurgeries = surgeriesList.length > 0 ? surgeriesList : [
    { id: 'S1', name: 'Coronary Artery Bypass', estDuration: 180, minDuration: 150, maxDuration: 240 },
    { id: 'S2', name: 'Emergency Craniotomy', estDuration: 150, minDuration: 120, maxDuration: 210 },
    { id: 'S3', name: 'Complex Femur Fixation', estDuration: 120, minDuration: 90, maxDuration: 160 },
    { id: 'S4', name: 'Laparoscopic Cholecystectomy', estDuration: 90, minDuration: 75, maxDuration: 120 },
    { id: 'S5', name: 'Hernia Repair', estDuration: 60, minDuration: 45, maxDuration: 90 },
    { id: 'S6', name: 'Total Knee Replacement', estDuration: 120, minDuration: 100, maxDuration: 160 }
  ];

  // Map surgeries to ensure min, max, estimated bounds
  const surgeries = baseSurgeries.map((s, i) => {
    const est = parseInt(s.duration || s.expectedSurgeryDuration || s.estDuration || (60 + (i % 4) * 30), 10);
    const minD = parseInt(s.minDuration || Math.round(est * 0.8), 10);
    const maxD = parseInt(s.maxDuration || Math.round(est * 1.4), 10);
    return {
      id: s.id || `SURG-${i + 1}`,
      name: s.name || s.surgeryType || `Procedure ${i + 1}`,
      estDuration: est,
      minDuration: minD,
      maxDuration: maxD
    };
  });

  const totalEstimatedDuration = surgeries.reduce((sum, s) => sum + s.estDuration, 0);

  let totalCompletionTimeSum = 0;
  let minCompletionTime = Infinity;
  let maxCompletionTime = 0;
  let delayedCount = 0;
  let overloadCount = 0;
  let totalWaitTimeSum = 0;

  const durationDistribution = [];

  // Helper for Triangular Random Sample: (min, mode/est, max)
  const sampleTriangular = (min, mode, max) => {
    const u = Math.random();
    const c = (mode - min) / (max - min);
    if (u < c) {
      return min + Math.sqrt(u * (max - min) * (mode - min));
    }
    return max - Math.sqrt((1 - u) * (max - min) * (max - mode));
  };

  // Run N stochastic simulation trials
  for (let sim = 0; sim < numSimulations; sim++) {
    let simTotalTime = 0;
    let accumulatedWait = 0;

    surgeries.forEach((s) => {
      const sampledDuration = sampleTriangular(s.minDuration, s.estDuration, s.maxDuration);
      simTotalTime += sampledDuration;
      accumulatedWait += simTotalTime;
    });

    totalCompletionTimeSum += simTotalTime;
    totalWaitTimeSum += (accumulatedWait / surgeries.length);

    if (simTotalTime < minCompletionTime) minCompletionTime = simTotalTime;
    if (simTotalTime > maxCompletionTime) maxCompletionTime = simTotalTime;

    // Detect if schedule is delayed beyond estimated baseline
    if (simTotalTime > totalEstimatedDuration * 1.05) {
      delayedCount++;
    }

    // Detect if schedule overloads OR max capacity threshold (e.g. 480 mins / 8 hours shift)
    if (simTotalTime > maxCapacityMins) {
      overloadCount++;
    }

    // Store a sample subset for distribution histogram
    if (sim < 100 || sim % Math.floor(numSimulations / 50) === 0) {
      durationDistribution.push(Math.round(simTotalTime));
    }
  }

  const avgCompletionTime = Math.round(totalCompletionTimeSum / numSimulations);
  const probDelay = parseFloat(((delayedCount / numSimulations) * 100).toFixed(1));
  const probOverload = parseFloat(((overloadCount / numSimulations) * 100).toFixed(1));
  const avgWaitTime = Math.round(totalWaitTimeSum / numSimulations);

  const endTime = performance.now();
  const executionTimeMs = parseFloat((endTime - startTime).toFixed(3));

  return {
    iterations: numSimulations,
    totalSurgeries: surgeries.length,
    estimatedBaselineMins: totalEstimatedDuration,
    avgCompletionTime,
    minCompletionTime: Math.round(minCompletionTime),
    maxCompletionTime: Math.round(maxCompletionTime),
    probDelay,
    probOverload,
    avgWaitTime,
    durationDistribution: durationDistribution.slice(0, 50),
    executionTimeMs
  };
};
