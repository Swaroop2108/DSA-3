/**
 * Min-Heap / Max-Heap based Priority Queue implementation for Hospital Patient & Surgery Scheduling
 * Urgency Levels: EMERGENCY (1) > URGENT (2) > HIGH (3) > NORMAL (4) > ROUTINE (5)
 * Smaller numerical priority integer indicates higher clinical urgency.
 * In case of priority ties, older waiting time / admission time takes precedence (FIFO tie-breaking).
 */
export class PriorityQueue {
  constructor(comparator = null) {
    this.heap = [];
    // Default comparator: lower priority rank number = higher priority; earlier admission = tie breaker
    this.comparator = comparator || ((a, b) => {
      const pA = a.priority ?? 4;
      const pB = b.priority ?? 4;
      if (pA !== pB) return pA - pB; // lower numerical priority comes first
      const timeA = new Date(a.admissionDate || a.createdAt || 0).getTime();
      const timeB = new Date(b.admissionDate || b.createdAt || 0).getTime();
      return timeA - timeB; // earlier time comes first
    });
  }

  getParentIndex(i) { return Math.floor((i - 1) / 2); }
  getLeftChildIndex(i) { return 2 * i + 1; }
  getRightChildIndex(i) { return 2 * i + 2; }

  swap(i, j) {
    const temp = this.heap[i];
    this.heap[i] = this.heap[j];
    this.heap[j] = temp;
  }

  /**
   * Insert element into heap - O(log n)
   */
  insert(element) {
    this.heap.push(element);
    this.heapifyUp();
  }

  // Alias for push
  push(element) {
    this.insert(element);
  }

  heapifyUp() {
    let index = this.heap.length - 1;
    while (index > 0) {
      const parentIndex = this.getParentIndex(index);
      if (this.comparator(this.heap[index], this.heap[parentIndex]) < 0) {
        this.swap(index, parentIndex);
        index = parentIndex;
      } else {
        break;
      }
    }
  }

  /**
   * Extract highest priority element - O(log n)
   */
  extract() {
    if (this.heap.length === 0) return null;
    if (this.heap.length === 1) return this.heap.pop();

    const root = this.heap[0];
    this.heap[0] = this.heap.pop();
    this.heapifyDown();
    return root;
  }

  // Alias for poll
  poll() {
    return this.extract();
  }

  heapifyDown() {
    let index = 0;
    while (this.getLeftChildIndex(index) < this.heap.length) {
      let smallest = index;
      const left = this.getLeftChildIndex(index);
      const right = this.getRightChildIndex(index);

      if (left < this.heap.length && this.comparator(this.heap[left], this.heap[smallest]) < 0) {
        smallest = left;
      }
      if (right < this.heap.length && this.comparator(this.heap[right], this.heap[smallest]) < 0) {
        smallest = right;
      }

      if (smallest !== index) {
        this.swap(index, smallest);
        index = smallest;
      } else {
        break;
      }
    }
  }

  /**
   * Peek highest priority element - O(1)
   */
  peek() {
    return this.heap.length > 0 ? this.heap[0] : null;
  }

  size() {
    return this.heap.length;
  }

  isEmpty() {
    return this.heap.length === 0;
  }
}

export default PriorityQueue;
