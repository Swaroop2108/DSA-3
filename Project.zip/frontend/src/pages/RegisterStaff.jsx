import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import API from '../services/api';
import { UserCheck, ShieldCheck, AlertCircle, CheckCircle, ArrowLeft, Lock, Mail, Phone, User, Briefcase, Clock, FileText } from 'lucide-react';

const RegisterStaff = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    fullName: '',
    staffId: '',
    email: '',
    phone: '',
    department: 'General Surgery',
    role: 'Doctor',
    specialization: '',
    shift: 'Morning',
    password: '',
    confirmPassword: ''
  });

  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState(false);
  const [loading, setLoading] = useState(false);

  const validate = () => {
    if (!formData.fullName || formData.fullName.trim().length < 3) {
      return 'Full Name is required and must be at least 3 characters long.';
    }
    if (!formData.staffId || formData.staffId.trim().length < 3) {
      return 'Staff ID is required (e.g. STF-1025).';
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email || !emailRegex.test(formData.email.trim())) {
      return 'Please enter a valid email address.';
    }
    const phoneClean = formData.phone.trim();
    if (!phoneClean || phoneClean.length < 7) {
      return 'Please enter a valid phone number (at least 7 digits).';
    }
    if (!formData.department) {
      return 'Please select a department.';
    }
    if (!formData.role) {
      return 'Please select a role.';
    }
    if (!formData.specialization || formData.specialization.trim().length < 2) {
      return 'Please enter your medical specialization.';
    }
    if (!formData.password || formData.password.length < 6) {
      return 'Password is required and must be at least 6 characters long.';
    }
    if (formData.password !== formData.confirmPassword) {
      return 'Password and Confirm Password do not match.';
    }
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);

    try {
      const res = await API.post('/auth/register-staff', {
        fullName: formData.fullName,
        name: formData.fullName,
        staffId: formData.staffId,
        email: formData.email,
        phone: formData.phone,
        department: formData.department,
        role: formData.role,
        specialization: formData.specialization,
        shift: formData.shift,
        password: formData.password
      });

      if (res.data.success) {
        setSuccessMsg(true);
      }
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Registration failed. Please check details.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #0f766e 100%)',
      padding: '2rem 1rem'
    }}>
      <div style={{
        width: '100%',
        maxWidth: '620px',
        background: '#ffffff',
        borderRadius: 'var(--radius-lg)',
        boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.35)',
        overflow: 'hidden'
      }}>
        {/* Header Branding */}
        <div style={{
          background: 'linear-gradient(135deg, #0f766e 0%, #0d9488 100%)',
          color: '#ffffff',
          padding: '1.75rem 2rem',
          display: 'flex',
          justify: 'space-between',
          alignItems: 'center'
        }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem' }}>
              <span style={{ fontSize: '1.5rem' }}>🏥</span>
              <h2 style={{ color: '#ffffff', fontSize: '1.4rem', fontWeight: 700, margin: 0 }}>
                MediSchedule
              </h2>
            </div>
            <p style={{ color: '#ccfbf1', fontSize: '0.82rem', margin: '0.2rem 0 0' }}>
              New Medical Staff Account Registration
            </p>
          </div>

          <Link to="/login" style={{ color: '#ffffff', textDecoration: 'none', fontSize: '0.82rem', display: 'flex', alignItems: 'center', gap: '0.3rem', background: 'rgba(255,255,255,0.15)', padding: '0.4rem 0.75rem', borderRadius: '4px', fontWeight: 600 }}>
            <ArrowLeft size={16} /> Back to Login
          </Link>
        </div>

        {/* Body Section */}
        <div style={{ padding: '2rem' }}>
          {successMsg ? (
            <div style={{ textAlign: 'center', padding: '1.5rem 0' }}>
              <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: '#ecfdf5', color: '#10b981', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 1.25rem' }}>
                <CheckCircle size={36} />
              </div>

              <h3 style={{ fontSize: '1.4rem', color: '#065f46', margin: '0 0 0.5rem', fontWeight: 800 }}>
                Registration Submitted Successfully!
              </h3>
              <p style={{ color: '#475569', fontSize: '0.92rem', marginBottom: '1.5rem', lineHeight: 1.5 }}>
                Your staff account for <strong>{formData.fullName}</strong> ({formData.staffId}) has been registered and is currently <strong>PENDING Admin approval</strong>.
              </p>

              <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid #cbd5e1', fontSize: '0.85rem', color: '#334155', marginBottom: '1.75rem', textAlign: 'left' }}>
                <strong>Account Status:</strong> <span className="badge badge-warning">PENDING APPROVAL</span><br />
                <strong>Email:</strong> {formData.email}<br />
                <strong>Role & Dept:</strong> {formData.role} • {formData.department}<br />
                <span style={{ fontSize: '0.78rem', color: '#64748b', marginTop: '0.3rem', display: 'block' }}>
                  ℹ️ An Administrator will review and approve your account. Once approved, you can log in using your credentials.
                </span>
              </div>

              <button
                onClick={() => navigate('/login')}
                className="btn btn-primary btn-lg"
                style={{ width: '100%' }}
              >
                Return to Login Page
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit}>
              {error && (
                <div style={{
                  background: 'var(--emergency-bg)',
                  border: '1px solid var(--emergency-border)',
                  color: 'var(--emergency)',
                  padding: '0.75rem 1rem',
                  borderRadius: 'var(--radius-sm)',
                  fontSize: '0.85rem',
                  marginBottom: '1.25rem',
                  display: 'flex',
                  alignItems: 'center',
                  gap: '0.5rem'
                }}>
                  <AlertCircle size={18} style={{ flexShrink: 0 }} />
                  <span>{error}</span>
                </div>
              )}

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
                {/* Full Name */}
                <div className="form-group">
                  <label className="form-label">Full Name *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Dr. Rahul Kumar"
                    value={formData.fullName}
                    onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                    className="form-control"
                  />
                </div>

                {/* Staff ID */}
                <div className="form-group">
                  <label className="form-label">Staff ID *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. STF-1025"
                    value={formData.staffId}
                    onChange={(e) => setFormData({ ...formData, staffId: e.target.value.toUpperCase() })}
                    className="form-control"
                  />
                </div>

                {/* Email */}
                <div className="form-group">
                  <label className="form-label">Email Address *</label>
                  <input
                    type="email"
                    required
                    placeholder="rahul@medischedule.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="form-control"
                  />
                </div>

                {/* Phone Number */}
                <div className="form-group">
                  <label className="form-label">Phone Number *</label>
                  <input
                    type="text"
                    required
                    placeholder="555-0199"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="form-control"
                  />
                </div>

                {/* Department */}
                <div className="form-group">
                  <label className="form-label">Department *</label>
                  <select
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                    className="form-control"
                  >
                    <option value="General Surgery">General Surgery</option>
                    <option value="Cardiology">Cardiology</option>
                    <option value="Orthopedics">Orthopedics</option>
                    <option value="Neurology">Neurology</option>
                    <option value="Emergency">Emergency</option>
                    <option value="Pediatrics">Pediatrics</option>
                    <option value="Gynecology">Gynecology</option>
                    <option value="Anesthesiology">Anesthesiology</option>
                    <option value="Radiology">Radiology</option>
                    <option value="Urology">Urology</option>
                  </select>
                </div>

                {/* Role */}
                <div className="form-group">
                  <label className="form-label">Medical Role *</label>
                  <select
                    value={formData.role}
                    onChange={(e) => setFormData({ ...formData, role: e.target.value })}
                    className="form-control"
                  >
                    <option value="Doctor">Doctor</option>
                    <option value="Surgeon">Surgeon</option>
                    <option value="Nurse">Nurse</option>
                    <option value="Anesthetist">Anesthetist</option>
                    <option value="Technician">Technician</option>
                    <option value="Other Staff">Other Staff</option>
                  </select>
                </div>

                {/* Specialization */}
                <div className="form-group">
                  <label className="form-label">Specialization *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Cardiothoracic Surgery"
                    value={formData.specialization}
                    onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                    className="form-control"
                  />
                </div>

                {/* Shift */}
                <div className="form-group">
                  <label className="form-label">Shift Duty *</label>
                  <select
                    value={formData.shift}
                    onChange={(e) => setFormData({ ...formData, shift: e.target.value })}
                    className="form-control"
                  >
                    <option value="Morning">Morning Shift (08:00 - 16:00)</option>
                    <option value="Afternoon">Afternoon Shift (14:00 - 22:00)</option>
                    <option value="Night">Night Shift (20:00 - 08:00)</option>
                    <option value="Rotating">Rotating Schedule</option>
                  </select>
                </div>

                {/* Password */}
                <div className="form-group">
                  <label className="form-label">Password *</label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="form-control"
                  />
                </div>

                {/* Confirm Password */}
                <div className="form-group">
                  <label className="form-label">Confirm Password *</label>
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={formData.confirmPassword}
                    onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                    className="form-control"
                  />
                </div>
              </div>

              <div style={{ display: 'flex', gap: '1rem', marginTop: '1.5rem' }}>
                <button
                  type="button"
                  onClick={() => navigate('/login')}
                  className="btn btn-secondary"
                  style={{ flex: 1 }}
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="btn btn-primary"
                  style={{ flex: 2 }}
                >
                  {loading ? 'Submitting Registration...' : 'Submit Staff Registration'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default RegisterStaff;
