import React, { useState, useEffect } from 'react';
import API from '../services/api';
import Modal from '../components/Common/Modal';
import { useAuth } from '../context/AuthContext';
import { UserCheck, Plus, Search, CheckCircle, Clock, ShieldCheck, AlertTriangle, Eye, XCircle, Check, RotateCcw } from 'lucide-react';

const StaffPage = () => {
  const { isAdmin } = useAuth();
  const [activeView, setActiveView] = useState('DIRECTORY'); // 'DIRECTORY' | 'ACCOUNTS'
  const [accountStatusFilter, setAccountStatusFilter] = useState('PENDING'); // 'PENDING' | 'ACTIVE' | 'REJECTED' | 'SUSPENDED' | 'ALL'

  const [staff, setStaff] = useState([]);
  const [staffAccounts, setStaffAccounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [roleFilter, setRoleFilter] = useState('');

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [viewAccountModal, setViewAccountModal] = useState(null);
  const [rejectModalAccount, setRejectModalAccount] = useState(null);
  const [rejectionReasonInput, setRejectionReasonInput] = useState('');

  const [formData, setFormData] = useState({
    name: '',
    role: 'Doctor',
    department: 'General Surgery',
    specialization: '',
    phone: '',
    email: '',
    availableFrom: '08:00',
    availableTo: '18:00'
  });

  useEffect(() => {
    fetchData();
  }, [roleFilter]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [staffRes, accountsRes] = await Promise.all([
        API.get(`/staff?role=${roleFilter}`),
        API.get('/staff/accounts')
      ]);

      if (staffRes.data.success) {
        setStaff(staffRes.data.staff);
      }
      if (accountsRes.data.success) {
        setStaffAccounts(accountsRes.data.accounts);
      }
    } catch (err) {
      console.error('Error fetching staff data:', err);
    } finally {
      setLoading(false);
    }
  };

  const pendingAccountsCount = staffAccounts.filter(a => a.status === 'PENDING').length;

  const handleCreateStaff = async (e) => {
    e.preventDefault();
    try {
      const res = await API.post('/staff', formData);
      if (res.data.success) {
        setIsAddModalOpen(false);
        fetchData();
      }
    } catch (err) {
      alert('Error creating staff: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleToggleStatus = async (staffMember, newStatus) => {
    try {
      const res = await API.put(`/staff/${staffMember.staffId}`, { status: newStatus });
      if (res.data.success) {
        fetchData();
      }
    } catch (err) {
      alert('Error updating staff status: ' + (err.response?.data?.message || err.message));
    }
  };

  // Account Action Handlers (Approve, Reject, Suspend, Reactivate)
  const handleApproveAccount = async (account) => {
    if (!window.confirm(`Approve staff registration for ${account.fullName} (${account.staffId})?`)) {
      return;
    }
    try {
      const res = await API.put(`/staff/accounts/${account.id}/approve`);
      if (res.data.success) {
        fetchData();
      }
    } catch (err) {
      alert('Error approving account: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleConfirmRejectAccount = async () => {
    if (!rejectModalAccount) return;
    try {
      const res = await API.put(`/staff/accounts/${rejectModalAccount.id}/reject`, {
        rejectionReason: rejectionReasonInput
      });
      if (res.data.success) {
        setRejectModalAccount(null);
        setRejectionReasonInput('');
        fetchData();
      }
    } catch (err) {
      alert('Error rejecting account: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleSuspendAccount = async (account) => {
    if (!window.confirm(`Suspend staff account for ${account.fullName} (${account.staffId})?`)) {
      return;
    }
    try {
      const res = await API.put(`/staff/accounts/${account.id}/suspend`);
      if (res.data.success) {
        fetchData();
      }
    } catch (err) {
      alert('Error suspending account: ' + (err.response?.data?.message || err.message));
    }
  };

  const handleReactivateAccount = async (account) => {
    if (!window.confirm(`Reactivate staff account for ${account.fullName} (${account.staffId})?`)) {
      return;
    }
    try {
      const res = await API.put(`/staff/accounts/${account.id}/reactivate`);
      if (res.data.success) {
        fetchData();
      }
    } catch (err) {
      alert('Error reactivating account: ' + (err.response?.data?.message || err.message));
    }
  };

  const filteredAccounts = staffAccounts.filter(acc => {
    if (accountStatusFilter === 'ALL') return true;
    return acc.status === accountStatusFilter;
  });

  return (
    <div className="page-wrapper">
      <div className="page-header">
        <div>
          <h1 className="page-title">Staff Management & Registration Approvals</h1>
          <p className="page-subtitle">Medical personnel directory, shift schedules, and staff account registration workflows.</p>
        </div>
        {isAdmin && (
          <button className="btn btn-primary" onClick={() => setIsAddModalOpen(true)}>
            <Plus size={18} /> Add Staff Member
          </button>
        )}
      </div>

      {/* Main Mode View Selector (Directory vs Registered Accounts / Pending Approvals) */}
      <div style={{ display: 'flex', gap: '0.75rem', marginBottom: '1.25rem', borderBottom: '2px solid var(--border)', paddingBottom: '0.5rem' }}>
        <button
          onClick={() => setActiveView('DIRECTORY')}
          style={{
            padding: '0.6rem 1.1rem',
            fontSize: '0.9rem',
            fontWeight: activeView === 'DIRECTORY' ? 700 : 500,
            color: activeView === 'DIRECTORY' ? 'var(--primary)' : '#64748b',
            background: 'transparent',
            border: 'none',
            borderBottom: activeView === 'DIRECTORY' ? '3px solid var(--primary)' : '3px solid transparent',
            cursor: 'pointer'
          }}
        >
          👥 Medical Staff Directory
        </button>

        {isAdmin && (
          <button
            onClick={() => setActiveView('ACCOUNTS')}
            style={{
              padding: '0.6rem 1.1rem',
              fontSize: '0.9rem',
              fontWeight: activeView === 'ACCOUNTS' ? 700 : 500,
              color: activeView === 'ACCOUNTS' ? 'var(--primary)' : '#64748b',
              background: 'transparent',
              border: 'none',
              borderBottom: activeView === 'ACCOUNTS' ? '3px solid var(--primary)' : '3px solid transparent',
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              gap: '0.4rem'
            }}
          >
            🛡️ Staff Account Registrations
            {pendingAccountsCount > 0 && (
              <span style={{
                background: '#ef4444',
                color: '#ffffff',
                fontSize: '0.7rem',
                padding: '0.15rem 0.5rem',
                borderRadius: '10px',
                fontWeight: 800
              }}>
                {pendingAccountsCount} Pending
              </span>
            )}
          </button>
        )}
      </div>

      {/* VIEW 1: MEDICAL STAFF DIRECTORY */}
      {activeView === 'DIRECTORY' && (
        <>
          {/* Role Filter Tabs */}
          <div className="card" style={{ marginBottom: '1.5rem', display: 'flex', gap: '0.75rem', overflowX: 'auto' }}>
            {['', 'Surgeon', 'Doctor', 'Nurse', 'Anesthetist', 'Technician'].map(role => (
              <button
                key={role}
                onClick={() => setRoleFilter(role)}
                className={`btn ${roleFilter === role ? 'btn-primary' : 'btn-secondary'}`}
                style={{ fontSize: '0.82rem', padding: '0.4rem 0.85rem' }}
              >
                {role === '' ? '👥 All Medical Staff' : role}
              </button>
            ))}
          </div>

          {/* Staff Grid */}
          {loading ? (
            <div style={{ padding: '3rem', textAlign: 'center' }}>Loading Medical Staff Directory...</div>
          ) : (
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
              gap: '1.25rem'
            }}>
              {staff.map(member => (
                <div key={member._id || member.staffId} className="card">
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                    <div>
                      <h3 style={{ fontSize: '1.05rem', fontWeight: 700 }}>{member.name}</h3>
                      <div style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 600 }}>
                        {member.role} • {member.department}
                      </div>
                    </div>
                    <span className={`badge ${member.status === 'AVAILABLE' ? 'badge-available' : (member.status === 'BUSY' ? 'badge-occupied' : 'badge-maintenance')}`}>
                      {member.status}
                    </span>
                  </div>

                  <div style={{ background: '#f8fafc', padding: '0.75rem', borderRadius: 'var(--radius-sm)', marginBottom: isAdmin ? '1rem' : '0', fontSize: '0.82rem' }}>
                    <div><strong>ID:</strong> {member.staffId}</div>
                    <div><strong>Specialization:</strong> {member.specialization}</div>
                    <div><strong>Working Hours:</strong> {member.availableFrom || '08:00'} - {member.availableTo || '18:00'}</div>
                    <div><strong>Contact:</strong> {member.phone || member.email || 'N/A'}</div>
                  </div>

                  {isAdmin && (
                    <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                      <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>Status Toggle:</span>
                      <select
                        value={member.status}
                        onChange={(e) => handleToggleStatus(member, e.target.value)}
                        className="form-control"
                        style={{ fontSize: '0.75rem', flex: 1 }}
                      >
                        <option value="AVAILABLE">AVAILABLE</option>
                        <option value="BUSY">BUSY</option>
                        <option value="OFF-DUTY">OFF-DUTY</option>
                      </select>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* VIEW 2: STAFF ACCOUNT REGISTRATION APPROVALS */}
      {activeView === 'ACCOUNTS' && isAdmin && (
        <>
          {/* Status Filters */}
          <div className="card" style={{ marginBottom: '1.5rem', display: 'flex', gap: '0.75rem', overflowX: 'auto', flexWrap: 'wrap' }}>
            <button
              onClick={() => setAccountStatusFilter('PENDING')}
              className={`btn ${accountStatusFilter === 'PENDING' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.82rem', padding: '0.4rem 0.85rem' }}
            >
              ⏳ Pending Approvals ({staffAccounts.filter(a => a.status === 'PENDING').length})
            </button>
            <button
              onClick={() => setAccountStatusFilter('ACTIVE')}
              className={`btn ${accountStatusFilter === 'ACTIVE' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.82rem', padding: '0.4rem 0.85rem' }}
            >
              ✅ Active Staff Accounts ({staffAccounts.filter(a => a.status === 'ACTIVE').length})
            </button>
            <button
              onClick={() => setAccountStatusFilter('REJECTED')}
              className={`btn ${accountStatusFilter === 'REJECTED' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.82rem', padding: '0.4rem 0.85rem' }}
            >
              🚫 Rejected Registrations ({staffAccounts.filter(a => a.status === 'REJECTED').length})
            </button>
            <button
              onClick={() => setAccountStatusFilter('SUSPENDED')}
              className={`btn ${accountStatusFilter === 'SUSPENDED' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.82rem', padding: '0.4rem 0.85rem' }}
            >
              ⛔ Suspended Accounts ({staffAccounts.filter(a => a.status === 'SUSPENDED').length})
            </button>
            <button
              onClick={() => setAccountStatusFilter('ALL')}
              className={`btn ${accountStatusFilter === 'ALL' ? 'btn-primary' : 'btn-secondary'}`}
              style={{ fontSize: '0.82rem', padding: '0.4rem 0.85rem' }}
            >
              All Accounts ({staffAccounts.length})
            </button>
          </div>

          {/* Accounts Grid */}
          {filteredAccounts.length === 0 ? (
            <div className="card" style={{ padding: '3rem', textAlign: 'center', color: '#64748b' }}>
              No staff accounts found matching status filter "{accountStatusFilter}".
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: '1.25rem' }}>
              {filteredAccounts.map(account => (
                <div key={account.id} className="card" style={{ borderLeft: account.status === 'PENDING' ? '4px solid #eab308' : account.status === 'ACTIVE' ? '4px solid #10b981' : '4px solid #ef4444' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: '0.75rem' }}>
                    <div>
                      <h3 style={{ fontSize: '1.1rem', fontWeight: 700, margin: 0 }}>{account.fullName || account.name}</h3>
                      <div style={{ fontSize: '0.8rem', color: 'var(--primary)', fontWeight: 600, marginTop: '0.1rem' }}>
                        {account.role} • {account.department}
                      </div>
                    </div>

                    <span className={`badge ${account.status === 'ACTIVE' ? 'badge-completed' : account.status === 'PENDING' ? 'badge-warning' : 'badge-occupied'}`}>
                      {account.status}
                    </span>
                  </div>

                  <div style={{ background: '#f8fafc', padding: '0.75rem', borderRadius: 'var(--radius-sm)', fontSize: '0.82rem', marginBottom: '1rem' }}>
                    <div><strong>Staff ID:</strong> {account.staffId}</div>
                    <div><strong>Email:</strong> {account.email}</div>
                    <div><strong>Specialization:</strong> {account.specialization}</div>
                    <div><strong>Shift:</strong> {account.shift || 'Morning'}</div>
                    <div><strong>Registered On:</strong> {new Date(account.registeredAt).toLocaleDateString()}</div>
                    {account.rejectionReason && (
                      <div style={{ color: '#b91c1c', marginTop: '0.3rem' }}>
                        <strong>Rejection Reason:</strong> {account.rejectionReason}
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                    <button
                      onClick={() => setViewAccountModal(account)}
                      className="btn btn-secondary"
                      style={{ fontSize: '0.75rem', padding: '0.35rem 0.65rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                    >
                      <Eye size={14} /> View
                    </button>

                    {account.status === 'PENDING' && (
                      <>
                        <button
                          onClick={() => handleApproveAccount(account)}
                          className="btn btn-primary"
                          style={{ fontSize: '0.75rem', padding: '0.35rem 0.65rem', background: '#10b981', borderColor: '#10b981', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                        >
                          <Check size={14} /> Approve
                        </button>
                        <button
                          onClick={() => setRejectModalAccount(account)}
                          className="btn btn-secondary"
                          style={{ fontSize: '0.75rem', padding: '0.35rem 0.65rem', color: '#ef4444', borderColor: '#fca5a5', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                        >
                          <XCircle size={14} /> Reject
                        </button>
                      </>
                    )}

                    {account.status === 'ACTIVE' && (
                      <button
                        onClick={() => handleSuspendAccount(account)}
                        className="btn btn-secondary"
                        style={{ fontSize: '0.75rem', padding: '0.35rem 0.65rem', color: '#b91c1c', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                      >
                        <AlertTriangle size={14} /> Suspend
                      </button>
                    )}

                    {(account.status === 'SUSPENDED' || account.status === 'REJECTED') && (
                      <button
                        onClick={() => handleReactivateAccount(account)}
                        className="btn btn-primary"
                        style={{ fontSize: '0.75rem', padding: '0.35rem 0.65rem', display: 'flex', alignItems: 'center', gap: '0.3rem' }}
                      >
                        <RotateCcw size={14} /> Reactivate / Approve
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </>
      )}

      {/* VIEW ACCOUNT DETAILS MODAL */}
      <Modal
        isOpen={Boolean(viewAccountModal)}
        onClose={() => setViewAccountModal(null)}
        title="Staff Account Details"
      >
        {viewAccountModal && (
          <div style={{ fontSize: '0.9rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', borderBottom: '1px solid var(--border)', paddingBottom: '0.75rem' }}>
              <div>
                <h3 style={{ margin: 0, fontSize: '1.2rem' }}>{viewAccountModal.fullName || viewAccountModal.name}</h3>
                <div style={{ color: 'var(--primary)', fontWeight: 600 }}>{viewAccountModal.role} • {viewAccountModal.department}</div>
              </div>
              <span className={`badge ${viewAccountModal.status === 'ACTIVE' ? 'badge-completed' : viewAccountModal.status === 'PENDING' ? 'badge-warning' : 'badge-occupied'}`}>
                {viewAccountModal.status}
              </span>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem', marginBottom: '1.25rem' }}>
              <div><strong>Staff ID:</strong> {viewAccountModal.staffId}</div>
              <div><strong>Email:</strong> {viewAccountModal.email}</div>
              <div><strong>Phone:</strong> {viewAccountModal.phone || 'N/A'}</div>
              <div><strong>Shift:</strong> {viewAccountModal.shift || 'Morning'}</div>
              <div><strong>Specialization:</strong> {viewAccountModal.specialization}</div>
              <div><strong>Registered Date:</strong> {new Date(viewAccountModal.registeredAt).toLocaleString()}</div>
              {viewAccountModal.approvedAt && <div><strong>Approved Date:</strong> {new Date(viewAccountModal.approvedAt).toLocaleString()}</div>}
              {viewAccountModal.rejectedAt && <div><strong>Rejected Date:</strong> {new Date(viewAccountModal.rejectedAt).toLocaleString()}</div>}
              {viewAccountModal.rejectionReason && <div style={{ gridColumn: 'span 2', color: '#b91c1c' }}><strong>Rejection Reason:</strong> {viewAccountModal.rejectionReason}</div>}
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button className="btn btn-secondary" onClick={() => setViewAccountModal(null)}>Close</button>
              {viewAccountModal.status === 'PENDING' && (
                <button
                  className="btn btn-primary"
                  style={{ background: '#10b981', borderColor: '#10b981' }}
                  onClick={() => {
                    const acc = viewAccountModal;
                    setViewAccountModal(null);
                    handleApproveAccount(acc);
                  }}
                >
                  Approve Registration
                </button>
              )}
            </div>
          </div>
        )}
      </Modal>

      {/* REJECT ACCOUNT MODAL */}
      <Modal
        isOpen={Boolean(rejectModalAccount)}
        onClose={() => setRejectModalAccount(null)}
        title="Reject Staff Registration"
      >
        {rejectModalAccount && (
          <div>
            <p style={{ fontSize: '0.9rem', marginBottom: '1rem' }}>
              Are you sure you want to reject staff registration for <strong>{rejectModalAccount.fullName}</strong> ({rejectModalAccount.staffId})?
            </p>

            <div className="form-group" style={{ marginBottom: '1.25rem' }}>
              <label className="form-label">Rejection Reason (Optional)</label>
              <textarea
                rows="3"
                placeholder="e.g. Invalid Staff ID or credentials verification failed."
                value={rejectionReasonInput}
                onChange={(e) => setRejectionReasonInput(e.target.value)}
                className="form-control"
              />
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem' }}>
              <button className="btn btn-secondary" onClick={() => setRejectModalAccount(null)}>Cancel</button>
              <button className="btn btn-primary" style={{ background: '#ef4444', borderColor: '#ef4444' }} onClick={handleConfirmRejectAccount}>
                Confirm Rejection
              </button>
            </div>
          </div>
        )}
      </Modal>

      {/* Add Staff Modal (Existing Admin Modal) */}
      <Modal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        title="Register Medical Staff Directory Entry"
      >
        <form onSubmit={handleCreateStaff} className="form-grid">
          <div className="form-group">
            <label className="form-label">Full Name *</label>
            <input type="text" required placeholder="e.g. Dr. Rajesh Kumar" value={formData.name} onChange={(e) => setFormData(p => ({ ...p, name: e.target.value }))} className="form-control" />
          </div>

          <div className="form-group">
            <label className="form-label">Role *</label>
            <select value={formData.role} onChange={(e) => setFormData(p => ({ ...p, role: e.target.value }))} className="form-control">
              <option value="Surgeon">Surgeon</option>
              <option value="Doctor">Doctor</option>
              <option value="Nurse">Nurse</option>
              <option value="Anesthetist">Anesthetist</option>
              <option value="Technician">Technician</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Department *</label>
            <select value={formData.department} onChange={(e) => setFormData(p => ({ ...p, department: e.target.value }))} className="form-control">
              <option value="General Surgery">General Surgery</option>
              <option value="Cardiology">Cardiology</option>
              <option value="Orthopedics">Orthopedics</option>
              <option value="Neurology">Neurology</option>
              <option value="Emergency">Emergency</option>
            </select>
          </div>

          <div className="form-group">
            <label className="form-label">Specialization</label>
            <input type="text" placeholder="Laparoscopic Surgery" value={formData.specialization} onChange={(e) => setFormData(p => ({ ...p, specialization: e.target.value }))} className="form-control" />
          </div>

          <div className="form-group">
            <label className="form-label">Available From</label>
            <input type="time" value={formData.availableFrom} onChange={(e) => setFormData(p => ({ ...p, availableFrom: e.target.value }))} className="form-control" />
          </div>

          <div className="form-group">
            <label className="form-label">Available To</label>
            <input type="time" value={formData.availableTo} onChange={(e) => setFormData(p => ({ ...p, availableTo: e.target.value }))} className="form-control" />
          </div>

          <div className="form-group full-width" style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '1rem' }}>
            <button type="button" className="btn btn-secondary" onClick={() => setIsAddModalOpen(false)}>Cancel</button>
            <button type="submit" className="btn btn-primary">Save Medical Staff</button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default StaffPage;
