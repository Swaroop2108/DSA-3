import React, { useState, useEffect } from 'react';
import { runLPTScheduling } from '../../algorithms/co5/lptScheduling';
import { getItem } from '../../services/storage';
import { Play, RefreshCw, BarChart2, CheckCircle, Database, Info, Clock, Layers } from 'lucide-react';

const CO5Approximation = () => {
  const [numORs, setNumORs] = useState(4);
  const [surgeriesData, setSurgeriesData] = useState([]);
  const [result, setResult] = useState(null);
  const [isDemoData, setIsDemoData] = useState(false);

  const loadData = () => {
    const localSurgeries = getItem('medischedule_surgeries', []);
    if (localSurgeries && localSurgeries.length >= 4) {
      setSurgeriesData(localSurgeries);
      setIsDemoData(false);
    } else {
      // Demo dataset with 10 surgeries of varying durations
      const demoSurgeries = [
        { id: 'S1', surgeryType: 'Coronary Artery Bypass (CABG)', duration: 210, patientName: 'Elena Rostova' },
        { id: 'S2', surgeryType: 'Emergency Craniotomy', duration: 180, patientName: 'James Wilson' },
        { id: 'S3', surgeryType: 'Aortic Valve Replacement', duration: 160, patientName: 'Vikramaditya Rao' },
        { id: 'S4', surgeryType: 'Complex Femur Fixation', duration: 140, patientName: 'Michael Chang' },
        { id: 'S5', surgeryType: 'Abdominal Trauma Surgery', duration: 120, patientName: 'Jessica Alba' },
        { id: 'S6', surgeryType: 'Total Knee Arthroplasty', duration: 120, patientName: 'Priya Sharma' },
        { id: 'S7', surgeryType: 'Laparoscopic Cholecystectomy', duration: 90, patientName: 'Sophia Patel' },
        { id: 'S8', surgeryType: 'Partial Thyroidectomy', duration: 90, patientName: 'Chloe Bennett' },
        { id: 'S9', surgeryType: 'Acute Appendectomy', duration: 60, patientName: 'Robert Vance' },
        { id: 'S10', surgeryType: 'Inguinal Hernia Repair', duration: 60, patientName: 'David Miller' }
      ];
      setSurgeriesData(demoSurgeries);
      setIsDemoData(true);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleRunAlgorithm = () => {
    const output = runLPTScheduling(surgeriesData, numORs);
    setResult(output);
  };

  useEffect(() => {
    if (surgeriesData.length > 0) {
      handleRunAlgorithm();
    }
  }, [numORs, surgeriesData]);

  return (
    <div className="card" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
      {/* Module Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.35rem' }}>
            <span className="badge badge-scheduled" style={{ fontSize: '0.75rem', fontWeight: 700 }}>CO5</span>
            <h2 style={{ fontSize: '1.3rem', color: 'var(--primary-text)', margin: 0 }}>
              LPT Approximation Algorithm for Multi-OR Scheduling
            </h2>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', margin: 0 }}>
            <strong>Course Outcome:</strong> NP-completeness, NP-hard problems, and approximation algorithms with provable worst-case ratios.
          </p>
        </div>

        <button 
          onClick={handleRunAlgorithm}
          className="btn btn-primary" 
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.6rem 1.25rem', fontSize: '0.92rem' }}
        >
          <Play size={18} /> Run LPT Approximation
        </button>
      </div>

      {/* Meta Specs Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.85rem', marginBottom: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Hospital Use Case</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', marginTop: '0.2rem' }}>
            Multi-OR workload balancing to minimize overall schedule makespan C_max.
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Time Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--primary)', fontWeight: 600, marginTop: '0.2rem' }}>
            Sort: O(n log n) | Min-Heap Assign: O(n log m)
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Theoretical Guarantee</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', fontWeight: 600, marginTop: '0.2rem' }}>
            C_max / OPT ≤ (4/3 - 1/3m)
          </div>
        </div>
      </div>

      {/* Inputs Control */}
      <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '1rem', marginBottom: '1.5rem', background: '#ffffff' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
          <div>
            <label style={{ fontSize: '0.82rem', fontWeight: 700, color: '#475569', display: 'block', marginBottom: '0.3rem' }}>
              Number of Available Operating Rooms (m):
            </label>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
              <input 
                type="range"
                min="2"
                max="8"
                value={numORs}
                onChange={(e) => setNumORs(parseInt(e.target.value, 10))}
                style={{ width: '180px' }}
              />
              <span style={{ fontSize: '1rem', fontWeight: 800, color: 'var(--primary)', minWidth: '40px' }}>
                m = {numORs}
              </span>
            </div>
          </div>

          <div style={{ fontSize: '0.85rem', color: '#64748b' }}>
            Surgeries to assign: <strong>{surgeriesData.length} Cases</strong>
            {isDemoData && <span className="badge badge-warning" style={{ marginLeft: '0.5rem', fontSize: '0.65rem' }}>Demo Dataset</span>}
          </div>
        </div>
      </div>

      {/* Execution Results */}
      {result && (
        <div style={{ marginTop: '1.5rem', animation: 'fadeIn 0.2s ease-in' }}>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#ecfdf5', border: '1px solid #a7f3d0' }}>
              <div style={{ fontSize: '0.75rem', color: '#047857', fontWeight: 600 }}>Achieved Makespan (C_max)</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#065f46' }}>{result.makespan} mins</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#eff6ff', border: '1px solid #bfdbfe' }}>
              <div style={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 600 }}>OPT Lower Bound</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#1e40af' }}>{result.optLowerBound} mins</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#fef3c7', border: '1px solid #fde68a' }}>
              <div style={{ fontSize: '0.75rem', color: '#b45309', fontWeight: 600 }}>Theoretical LPT Bound</div>
              <div style={{ fontSize: '1.3rem', fontWeight: 800, color: '#92400e' }}>{result.theoreticalBoundRatioStr}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: 600 }}>Average OR Utilization</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0f172a' }}>{result.avgUtilization}%</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '160px', padding: '0.85rem', background: '#f3e8ff', border: '1px solid #e9d5ff' }}>
              <div style={{ fontSize: '0.75rem', color: '#6b21a8', fontWeight: 600 }}>Execution Time</div>
              <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#581c87' }}>{result.executionTimeMs} ms</div>
            </div>
          </div>

          {/* Operating Room Workload Distribution Breakdown */}
          <h4 style={{ fontSize: '1rem', color: 'var(--text-main)', marginBottom: '0.75rem' }}>
            📊 Balanced Operating Room Workload Schedule (LPT Min-Heap Assignment)
          </h4>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem', marginBottom: '1.5rem' }}>
            {result.orSchedules.map((room) => {
              const utilPct = result.makespan > 0 ? Math.round((room.totalDuration / result.makespan) * 100) : 0;
              const isMakespanRoom = room.totalDuration === result.makespan;

              return (
                <div 
                  key={room.orId}
                  style={{
                    border: isMakespanRoom ? '2px solid #ef4444' : '1px solid var(--border)',
                    borderRadius: 'var(--radius-sm)',
                    padding: '1rem',
                    background: isMakespanRoom ? '#fef2f2' : '#ffffff'
                  }}
                >
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.5rem' }}>
                    <div style={{ fontWeight: 700, fontSize: '0.95rem', color: 'var(--primary-text)' }}>
                      🏥 {room.name}
                    </div>
                    {isMakespanRoom && (
                      <span className="badge" style={{ background: '#ef4444', color: '#ffffff', fontSize: '0.65rem' }}>
                        Makespan C_max
                      </span>
                    )}
                  </div>

                  <div style={{ fontSize: '0.82rem', color: '#475569', marginBottom: '0.6rem' }}>
                    Total Workload: <strong>{room.totalDuration} mins</strong> ({room.assignedSurgeries.length} procedures)
                  </div>

                  {/* Progress Utilization Bar */}
                  <div style={{ background: '#e2e8f0', borderRadius: '4px', height: '8px', overflow: 'hidden', marginBottom: '0.75rem' }}>
                    <div style={{ width: `${utilPct}%`, background: isMakespanRoom ? '#ef4444' : 'var(--primary)', height: '100%' }} />
                  </div>

                  {/* Assigned Surgeries */}
                  <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                    {room.assignedSurgeries.map((s, idx) => (
                      <div key={idx} style={{ background: '#f8fafc', padding: '0.4rem 0.6rem', borderRadius: '4px', border: '1px solid #e2e8f0', fontSize: '0.78rem', display: 'flex', justifyContent: 'space-between' }}>
                        <span>{idx + 1}. {s.name} ({s.patientName})</span>
                        <strong style={{ color: 'var(--primary)' }}>{s.duration} m</strong>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Theoretical Explanation */}
      <div style={{ marginTop: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', borderLeft: '4px solid var(--primary)', fontSize: '0.85rem' }}>
        <h5 style={{ margin: '0 0 0.4rem', color: 'var(--primary-text)', fontSize: '0.92rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <Info size={16} /> Provable LPT Approximation Ratio Guarantee
        </h5>
        <p style={{ margin: 0, color: '#334155', lineHeight: 1.5 }}>
          Parallel machine scheduling (Pm || Cmax) is a classic <strong>NP-hard problem</strong>. The <strong>Longest Processing Time (LPT)</strong> greedy heuristic sorts jobs by decreasing duration and assigns each job to the least-loaded machine. Graham proved that LPT satisfies the strict approximation ratio bound:
          <br />
          <strong>Cmax / OPT ≤ 4/3 - 1/(3m)</strong>
          <br />
          This guarantees that for m = 4 operating rooms, the schedule makespan is never worse than 1.25 × OPT.
        </p>
      </div>
    </div>
  );
};

export default CO5Approximation;
