import React, { useState, useEffect } from 'react';
import { runHospitalEdmondsKarp } from '../../algorithms/co4/edmondsKarp';
import { getItem } from '../../services/storage';
import { Play, RefreshCw, GitMerge, CheckCircle, Database, Info, Activity, ShieldAlert } from 'lucide-react';

const CO4MaxFlow = () => {
  const [scenario, setScenario] = useState('NORMAL');
  const [result, setResult] = useState(null);

  const runAlgorithm = () => {
    const patients = getItem('medischedule_patients', []);
    const ors = getItem('medischedule_operating_rooms', []);
    const beds = getItem('medischedule_beds', []);

    // Custom capacity scenarios
    let resourceCapacities = [];
    if (scenario === 'SURGE') {
      // Emergency surge with high patient load and restricted ICU beds
      resourceCapacities = [
        { id: 'RES_OR_GEN', name: 'General OR Suite', type: 'OR', capacity: 2 },
        { id: 'RES_OR_CARD', name: 'Cardiac OR Suite', type: 'OR', capacity: 1 },
        { id: 'RES_OR_ORTHO', name: 'Orthopedic OR Suite', type: 'OR', capacity: 1 },
        { id: 'RES_ICU', name: 'ICU Recovery Bed', type: 'BED', capacity: 2 },
        { id: 'RES_GEN_BED', name: 'General Ward Bed', type: 'BED', capacity: 4 }
      ];
    } else if (scenario === 'EXPANDED') {
      // High capacity expansion
      resourceCapacities = [
        { id: 'RES_OR_GEN', name: 'General OR Suite', type: 'OR', capacity: 5 },
        { id: 'RES_OR_CARD', name: 'Cardiac OR Suite', type: 'OR', capacity: 3 },
        { id: 'RES_OR_ORTHO', name: 'Orthopedic OR Suite', type: 'OR', capacity: 4 },
        { id: 'RES_ICU', name: 'ICU Recovery Bed', type: 'BED', capacity: 6 },
        { id: 'RES_GEN_BED', name: 'General Ward Bed', type: 'BED', capacity: 8 }
      ];
    } else {
      // Normal baseline capacities
      resourceCapacities = [
        { id: 'RES_OR_GEN', name: 'General OR Suite', type: 'OR', capacity: 3 },
        { id: 'RES_OR_CARD', name: 'Cardiac OR Suite', type: 'OR', capacity: 2 },
        { id: 'RES_OR_ORTHO', name: 'Orthopedic OR Suite', type: 'OR', capacity: 2 },
        { id: 'RES_ICU', name: 'ICU Recovery Bed', type: 'BED', capacity: 3 },
        { id: 'RES_GEN_BED', name: 'General Ward Bed', type: 'BED', capacity: 5 }
      ];
    }

    const output = runHospitalEdmondsKarp(patients, resourceCapacities);
    setResult(output);
  };

  useEffect(() => {
    runAlgorithm();
  }, [scenario]);

  return (
    <div className="card" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
      {/* Module Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.35rem' }}>
            <span className="badge badge-scheduled" style={{ fontSize: '0.75rem', fontWeight: 700 }}>CO4</span>
            <h2 style={{ fontSize: '1.3rem', color: 'var(--primary-text)', margin: 0 }}>
              Edmonds-Karp Maximum Flow Resource Allocator
            </h2>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', margin: 0 }}>
            <strong>Course Outcome:</strong> Network-flow algorithms including Ford-Fulkerson with Edmonds-Karp BFS and max-flow/min-cut.
          </p>
        </div>

        <button 
          onClick={runAlgorithm}
          className="btn btn-primary" 
          style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.6rem 1.25rem', fontSize: '0.92rem' }}
        >
          <Play size={18} /> Compute Max Flow
        </button>
      </div>

      {/* Meta Specs Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.85rem', marginBottom: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Hospital Use Case</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', marginTop: '0.2rem' }}>
            Source ➔ Patients ➔ OR & Bed Resource Nodes ➔ Sink Network Optimization.
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Time Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--primary)', fontWeight: 600, marginTop: '0.2rem' }}>
            O(V * E²) BFS Augmenting Paths
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Space Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', fontWeight: 600, marginTop: '0.2rem' }}>
            O(V + E) Flow & Residual Graph
          </div>
        </div>
      </div>

      {/* Scenario Control */}
      <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '1rem', marginBottom: '1.5rem', background: '#ffffff' }}>
        <label style={{ fontSize: '0.82rem', fontWeight: 700, color: '#475569', display: 'block', marginBottom: '0.5rem' }}>
          Select Hospital Resource Capacity Scenario:
        </label>
        <div style={{ display: 'flex', gap: '0.75rem', flexWrap: 'wrap' }}>
          <button
            onClick={() => setScenario('NORMAL')}
            className={`btn ${scenario === 'NORMAL' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ fontSize: '0.82rem', padding: '0.45rem 1rem' }}
          >
            Normal Operational Baseline
          </button>
          <button
            onClick={() => setScenario('SURGE')}
            className={`btn ${scenario === 'SURGE' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ fontSize: '0.82rem', padding: '0.45rem 1rem' }}
          >
            Emergency Surge (Restricted ICU & ORs)
          </button>
          <button
            onClick={() => setScenario('EXPANDED')}
            className={`btn ${scenario === 'EXPANDED' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ fontSize: '0.82rem', padding: '0.45rem 1rem' }}
          >
            Expanded Surgical Capacity
          </button>
        </div>
      </div>

      {/* Execution Results */}
      {result && (
        <div style={{ marginTop: '1.5rem', animation: 'fadeIn 0.2s ease-in' }}>
          <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#ecfdf5', border: '1px solid #a7f3d0' }}>
              <div style={{ fontSize: '0.75rem', color: '#047857', fontWeight: 600 }}>Maximum Flow</div>
              <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#065f46' }}>{result.maxFlow} units</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#eff6ff', border: '1px solid #bfdbfe' }}>
              <div style={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 600 }}>Allocated Patients</div>
              <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#1e40af' }}>{result.allocatedPatients} / {result.totalPatients}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#fef2f2', border: '1px solid #fecaca' }}>
              <div style={{ fontSize: '0.75rem', color: '#b91c1c', fontWeight: 600 }}>Unallocated Patients</div>
              <div style={{ fontSize: '1.6rem', fontWeight: 800, color: '#991b1b' }}>{result.unallocatedPatients}</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
              <div style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: 600 }}>Network Nodes / Edges</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#0f172a' }}>{result.nodesCount} V | {result.edgesCount} E</div>
            </div>
            <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#f3e8ff', border: '1px solid #e9d5ff' }}>
              <div style={{ fontSize: '0.75rem', color: '#6b21a8', fontWeight: 600 }}>Execution Time</div>
              <div style={{ fontSize: '1.4rem', fontWeight: 800, color: '#581c87' }}>{result.executionTimeMs} ms</div>
            </div>
          </div>

          {/* Flow Network Diagram Visualization */}
          <h4 style={{ fontSize: '1rem', color: 'var(--text-main)', marginBottom: '0.75rem' }}>
            🌐 Network Flow & Capacity Allocation Diagram
          </h4>

          <div style={{ background: '#090d16', borderRadius: 'var(--radius-sm)', padding: '1.25rem', marginBottom: '1.5rem', color: '#ffffff', overflowX: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: '1rem', minWidth: '650px' }}>
              {/* SOURCE NODE */}
              <div style={{ background: '#1e293b', border: '2px solid #0284c7', borderRadius: '8px', padding: '1rem', textAlign: 'center', width: '130px' }}>
                <div style={{ fontSize: '0.7rem', color: '#38bdf8', fontWeight: 700 }}>SOURCE</div>
                <div style={{ fontSize: '0.9rem', fontWeight: 800, color: '#ffffff' }}>Hospital Admissions</div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '0.3rem' }}>Flow: {result.maxFlow}</div>
              </div>

              <div style={{ fontSize: '1.5rem', color: '#0284c7', fontWeight: 800 }}>➔</div>

              {/* PATIENTS LAYER */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', flex: 1 }}>
                <div style={{ fontSize: '0.7rem', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 700, textAlign: 'center' }}>Patients Layer ({result.totalPatients})</div>
                <div style={{ background: '#1e293b', borderRadius: '6px', padding: '0.6rem', border: '1px solid #334155', fontSize: '0.78rem' }}>
                  {result.nodes.filter(n => n.type === 'PATIENT').map(p => p.label.split(' ')[0]).join(', ')}
                </div>
              </div>

              <div style={{ fontSize: '1.5rem', color: '#0284c7', fontWeight: 800 }}>➔</div>

              {/* RESOURCE NODES LAYER */}
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem', flex: 1 }}>
                <div style={{ fontSize: '0.7rem', color: '#94a3b8', textTransform: 'uppercase', fontWeight: 700, textAlign: 'center' }}>Resource Capacity Nodes</div>
                {result.nodes.filter(n => n.type === 'RESOURCE').map((res) => {
                  const flowEdge = result.allocatedFlows.find(f => f.from === res.label || f.to === res.label);
                  return (
                    <div key={res.id} style={{ background: '#1e293b', border: '1px solid #475569', borderRadius: '6px', padding: '0.4rem 0.6rem', fontSize: '0.75rem', display: 'flex', justifyContent: 'space-between' }}>
                      <span>{res.label}</span>
                      <span style={{ color: '#38bdf8', fontWeight: 700 }}>{flowEdge ? `${flowEdge.flow}/${flowEdge.capacity}` : 'Cap'}</span>
                    </div>
                  );
                })}
              </div>

              <div style={{ fontSize: '1.5rem', color: '#0284c7', fontWeight: 800 }}>➔</div>

              {/* SINK NODE */}
              <div style={{ background: '#1e293b', border: '2px solid #10b981', borderRadius: '8px', padding: '1rem', textAlign: 'center', width: '130px' }}>
                <div style={{ fontSize: '0.7rem', color: '#34d399', fontWeight: 700 }}>SINK</div>
                <div style={{ fontSize: '0.9rem', fontWeight: 800, color: '#ffffff' }}>Completed Care</div>
                <div style={{ fontSize: '0.75rem', color: '#94a3b8', marginTop: '0.3rem' }}>Total: {result.maxFlow}</div>
              </div>
            </div>
          </div>

          {/* Augmenting Paths Log */}
          <h4 style={{ fontSize: '1rem', color: 'var(--text-main)', marginBottom: '0.75rem' }}>
            🔄 BFS Augmenting Paths Discovered by Edmonds-Karp
          </h4>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem', marginBottom: '1.5rem' }}>
            {result.augmentingPaths.map((p) => (
              <div key={p.pathNumber} style={{ border: '1px solid #cbd5e1', borderRadius: 'var(--radius-sm)', padding: '0.65rem 0.85rem', background: '#ffffff', fontSize: '0.82rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                  <span style={{ fontWeight: 700, color: 'var(--primary)' }}>Path #{p.pathNumber}:</span>
                  <span style={{ fontFamily: 'var(--font-mono)', color: '#334155' }}>{p.path}</span>
                </div>
                <span className="badge badge-scheduled" style={{ fontSize: '0.7rem', fontWeight: 700 }}>
                  + {p.bottleneck} Bottleneck Flow
                </span>
              </div>
            ))}
          </div>

          {/* Min-Cut Bottlenecks */}
          {result.minCutEdges.length > 0 && (
            <div>
              <h4 style={{ fontSize: '1rem', color: '#b91c1c', marginBottom: '0.75rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                <ShieldAlert size={18} /> Identified Min-Cut Resource Bottlenecks
              </h4>

              <div style={{ border: '1px solid #fecaca', borderRadius: 'var(--radius-sm)', background: '#fef2f2', padding: '0.85rem' }}>
                {result.minCutEdges.map((edge, idx) => (
                  <div key={idx} style={{ fontSize: '0.82rem', color: '#991b1b', marginBottom: '0.3rem' }}>
                    🚨 S-T Cut Edge: <strong>{edge.from} ➔ {edge.to}</strong> (Saturated Flow: {edge.flow} / {edge.capacity})
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Theoretical Explanation */}
      <div style={{ marginTop: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', borderLeft: '4px solid var(--primary)', fontSize: '0.85rem' }}>
        <h5 style={{ margin: '0 0 0.4rem', color: 'var(--primary-text)', fontSize: '0.92rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <Info size={16} /> Max-Flow Min-Cut Theorem in Hospital Resource Planning
        </h5>
        <p style={{ margin: 0, color: '#334155', lineHeight: 1.5 }}>
          The <strong>Max-Flow Min-Cut Theorem</strong> proves that the maximum amount of flow from Source to Sink equals the total capacity of edges in the minimum capacity cut. In MediSchedule, the Min-Cut pinpoints the exact physical bottlenecks (e.g. ICU Bed shortage or Cardiac OR constraints) restricting patient admissions.
        </p>
      </div>
    </div>
  );
};

export default CO4MaxFlow;
