import React, { useState, useEffect } from 'react';
import { runMonteCarloSimulation } from '../../algorithms/co6/monteCarlo';
import { runParallelPrefixSumAnalytics, generateHospitalDataset } from '../../algorithms/co6/parallelPrefixSum';
import { getItem } from '../../services/storage';
import { Play, RefreshCw, Activity, Cpu, CheckCircle, Database, Info, Sliders, Zap } from 'lucide-react';

const CO6RandomizedParallel = () => {
  const [activeTab, setActiveTab] = useState('CO6_A');

  // CO6-A Monte Carlo State
  const [mcIterations, setMcIterations] = useState(1000);
  const [mcResult, setMcResult] = useState(null);

  // CO6-B Parallel Analytics State
  const [datasetSize, setDatasetSize] = useState(100000);
  const [numWorkers, setNumWorkers] = useState(4);
  const [parResult, setParResult] = useState(null);
  const [isBenchmarking, setIsBenchmarking] = useState(false);

  const handleRunMonteCarlo = () => {
    const surgeries = getItem('medischedule_surgeries', []);
    const output = runMonteCarloSimulation(surgeries, mcIterations, 480);
    setMcResult(output);
  };

  const handleRunParallelBenchmark = async () => {
    setIsBenchmarking(true);
    // Generate synthetic dataset of specified size
    const data = generateHospitalDataset(datasetSize);
    const output = await runParallelPrefixSumAnalytics(data, numWorkers);
    setParResult(output);
    setIsBenchmarking(false);
  };

  useEffect(() => {
    handleRunMonteCarlo();
    handleRunParallelBenchmark();
  }, []);

  return (
    <div className="card" style={{ padding: '1.5rem', marginBottom: '2rem' }}>
      {/* Module Header */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: '1rem', marginBottom: '1.25rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.6rem', marginBottom: '0.35rem' }}>
            <span className="badge badge-scheduled" style={{ fontSize: '0.75rem', fontWeight: 700 }}>CO6</span>
            <h2 style={{ fontSize: '1.3rem', color: 'var(--primary-text)', margin: 0 }}>
              Monte Carlo Simulation & Parallel Analytics Primitives
            </h2>
          </div>
          <p style={{ color: 'var(--text-muted)', fontSize: '0.88rem', margin: 0 }}>
            <strong>Course Outcome:</strong> Randomized algorithms and parallel algorithm primitives (Prefix Sum / Reduce).
          </p>
        </div>

        {/* Sub-tab Switcher */}
        <div style={{ display: 'flex', gap: '0.5rem', background: '#f1f5f9', padding: '0.3rem', borderRadius: 'var(--radius-sm)' }}>
          <button
            onClick={() => setActiveTab('CO6_A')}
            style={{
              padding: '0.45rem 0.85rem',
              fontSize: '0.82rem',
              fontWeight: 700,
              borderRadius: '4px',
              border: 'none',
              background: activeTab === 'CO6_A' ? 'var(--primary)' : 'transparent',
              color: activeTab === 'CO6_A' ? '#ffffff' : '#64748b',
              cursor: 'pointer'
            }}
          >
            CO6-A Monte Carlo
          </button>
          <button
            onClick={() => setActiveTab('CO6_B')}
            style={{
              padding: '0.45rem 0.85rem',
              fontSize: '0.82rem',
              fontWeight: 700,
              borderRadius: '4px',
              border: 'none',
              background: activeTab === 'CO6_B' ? 'var(--primary)' : 'transparent',
              color: activeTab === 'CO6_B' ? '#ffffff' : '#64748b',
              cursor: 'pointer'
            }}
          >
            CO6-B Parallel Primitives
          </button>
        </div>
      </div>

      {/* Meta Specs Grid */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '0.85rem', marginBottom: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)' }}>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Hospital Use Case</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', marginTop: '0.2rem' }}>
            {activeTab === 'CO6_A' ? 'Stochastic uncertainty simulation for surgery delay & overload risk.' : 'High-speed parallel analytics (Prefix Sum / Reduce) on big data.'}
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Time Complexity</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--primary)', fontWeight: 600, marginTop: '0.2rem' }}>
            {activeTab === 'CO6_A' ? 'Monte Carlo: O(N * S)' : 'Parallel Prefix: O(n/p + log p)'}
          </div>
        </div>
        <div>
          <strong style={{ fontSize: '0.78rem', textTransform: 'uppercase', color: '#64748b' }}>Execution Primitive</strong>
          <div style={{ fontSize: '0.88rem', color: 'var(--text-main)', fontWeight: 600, marginTop: '0.2rem' }}>
            {activeTab === 'CO6_A' ? 'Triangular Random Sampling' : 'Web Worker Threads & Chunking'}
          </div>
        </div>
      </div>

      {/* SUB-SECTION A: MONTE CARLO SIMULATION */}
      {activeTab === 'CO6_A' && (
        <div>
          {/* Inputs Control */}
          <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '1rem', marginBottom: '1.5rem', background: '#ffffff' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
              <div>
                <label style={{ fontSize: '0.82rem', fontWeight: 700, color: '#475569', display: 'block', marginBottom: '0.4rem' }}>
                  Select Monte Carlo Simulation Iterations (N):
                </label>
                <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap' }}>
                  {[100, 500, 1000, 5000, 10000].map((num) => (
                    <button
                      key={num}
                      onClick={() => setMcIterations(num)}
                      className={`btn ${mcIterations === num ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ fontSize: '0.8rem', padding: '0.4rem 0.8rem' }}
                    >
                      {num.toLocaleString()} Runs
                    </button>
                  ))}
                </div>
              </div>

              <button 
                onClick={handleRunMonteCarlo}
                className="btn btn-primary" 
                style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.55rem 1.1rem', fontSize: '0.88rem' }}
              >
                <Play size={16} /> Run Simulation
              </button>
            </div>
          </div>

          {/* Results */}
          {mcResult && (
            <div style={{ animation: 'fadeIn 0.2s ease-in' }}>
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#eff6ff', border: '1px solid #bfdbfe' }}>
                  <div style={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 600 }}>Simulations Run</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#1e40af' }}>{mcResult.iterations.toLocaleString()}</div>
                </div>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#ecfdf5', border: '1px solid #a7f3d0' }}>
                  <div style={{ fontSize: '0.75rem', color: '#047857', fontWeight: 600 }}>Average Completion Time</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#065f46' }}>{mcResult.avgCompletionTime} mins</div>
                </div>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#fef3c7', border: '1px solid #fde68a' }}>
                  <div style={{ fontSize: '0.75rem', color: '#b45309', fontWeight: 600 }}>Probability of Delay</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#92400e' }}>{mcResult.probDelay}%</div>
                </div>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#fef2f2', border: '1px solid #fecaca' }}>
                  <div style={{ fontSize: '0.75rem', color: '#b91c1c', fontWeight: 600 }}>Probability of OR Overload</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#991b1b' }}>{mcResult.probOverload}%</div>
                </div>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                  <div style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: 600 }}>Min / Max Makespan</div>
                  <div style={{ fontSize: '1.2rem', fontWeight: 800, color: '#0f172a' }}>{mcResult.minCompletionTime}m - {mcResult.maxCompletionTime}m</div>
                </div>
              </div>

              {/* Stochastic Sample Distribution */}
              <h4 style={{ fontSize: '0.95rem', color: 'var(--text-main)', marginBottom: '0.6rem' }}>
                📈 Stochastic Schedule Completion Sample Distribution (Minutes)
              </h4>
              <div style={{ background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)', fontSize: '0.78rem', color: '#475569', display: 'flex', gap: '0.4rem', flexWrap: 'wrap' }}>
                {mcResult.durationDistribution.map((val, idx) => (
                  <span key={idx} style={{ background: '#ffffff', border: '1px solid #cbd5e1', padding: '0.2rem 0.4rem', borderRadius: '4px', fontWeight: 600 }}>
                    {val}m
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* SUB-SECTION B: PARALLEL PREFIX SUM / REDUCE */}
      {activeTab === 'CO6_B' && (
        <div>
          {/* Inputs Control */}
          <div style={{ border: '1px solid var(--border)', borderRadius: 'var(--radius-sm)', padding: '1rem', marginBottom: '1.5rem', background: '#ffffff' }}>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '1rem', marginBottom: '1rem' }}>
              <div>
                <label style={{ fontSize: '0.82rem', fontWeight: 700, color: '#475569', display: 'block', marginBottom: '0.3rem' }}>
                  Analytics Dataset Size (Records):
                </label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
                  <input 
                    type="range"
                    min="1000"
                    max="500000"
                    step="10000"
                    value={datasetSize}
                    onChange={(e) => setDatasetSize(parseInt(e.target.value, 10))}
                    style={{ flex: 1 }}
                  />
                  <span style={{ fontSize: '0.9rem', fontWeight: 800, color: 'var(--primary)', minWidth: '85px' }}>
                    {datasetSize.toLocaleString()}
                  </span>
                </div>
              </div>

              <div>
                <label style={{ fontSize: '0.82rem', fontWeight: 700, color: '#475569', display: 'block', marginBottom: '0.3rem' }}>
                  Parallel Web Worker Threads:
                </label>
                <select
                  value={numWorkers}
                  onChange={(e) => setNumWorkers(parseInt(e.target.value, 10))}
                  style={{ width: '100%', padding: '0.5rem', fontSize: '0.85rem', borderRadius: 'var(--radius-sm)', border: '1px solid #cbd5e1' }}
                >
                  <option value="2">2 Web Workers</option>
                  <option value="4">4 Web Workers</option>
                  <option value="8">8 Web Workers</option>
                </select>
              </div>
            </div>

            <button 
              onClick={handleRunParallelBenchmark}
              disabled={isBenchmarking}
              className="btn btn-primary" 
              style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.55rem 1.2rem', fontSize: '0.88rem' }}
            >
              {isBenchmarking ? <RefreshCw className="spin" size={16} /> : <Zap size={16} />}
              {isBenchmarking ? 'Running Workers Benchmark...' : 'Benchmark Parallel Analytics'}
            </button>
          </div>

          {/* Results */}
          {parResult && (
            <div style={{ animation: 'fadeIn 0.2s ease-in' }}>
              <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '1.25rem' }}>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#f8fafc', border: '1px solid #e2e8f0' }}>
                  <div style={{ fontSize: '0.75rem', color: '#64748b', fontWeight: 600 }}>Records Processed</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#0f172a' }}>{parResult.recordsProcessed.toLocaleString()}</div>
                </div>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#eff6ff', border: '1px solid #bfdbfe' }}>
                  <div style={{ fontSize: '0.75rem', color: '#1d4ed8', fontWeight: 600 }}>Sequential Execution</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#1e40af' }}>{parResult.sequentialTimeMs} ms</div>
                </div>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#ecfdf5', border: '1px solid #a7f3d0' }}>
                  <div style={{ fontSize: '0.75rem', color: '#047857', fontWeight: 600 }}>Parallel Execution ({parResult.workersCount} Workers)</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#065f46' }}>{parResult.parallelTimeMs} ms</div>
                </div>
                <div className="card" style={{ flex: 1, minWidth: '150px', padding: '0.85rem', background: '#f3e8ff', border: '1px solid #e9d5ff' }}>
                  <div style={{ fontSize: '0.75rem', color: '#6b21a8', fontWeight: 600 }}>Parallel Speedup Ratio</div>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: '#581c87' }}>{parResult.speedup}x</div>
                </div>
              </div>

              {/* Sample Output Array */}
              <h4 style={{ fontSize: '0.95rem', color: 'var(--text-main)', marginBottom: '0.6rem' }}>
                🧮 Sample Hospital Analytics Prefix Sum Output
              </h4>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)', fontSize: '0.8rem' }}>
                <div>
                  <strong>Sample Input Durations/Costs:</strong>
                  <div style={{ fontFamily: 'var(--font-mono)', marginTop: '0.3rem', color: '#334155' }}>
                    [{parResult.sampleInput.join(', ')}]
                  </div>
                </div>
                <div>
                  <strong>Calculated Prefix Sum Array:</strong>
                  <div style={{ fontFamily: 'var(--font-mono)', marginTop: '0.3rem', color: 'var(--primary)', fontWeight: 700 }}>
                    [{parResult.samplePrefix.join(', ')}]
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Theoretical Explanation */}
      <div style={{ marginTop: '1.5rem', background: '#f8fafc', padding: '1rem', borderRadius: 'var(--radius-sm)', borderLeft: '4px solid var(--primary)', fontSize: '0.85rem' }}>
        <h5 style={{ margin: '0 0 0.4rem', color: 'var(--primary-text)', fontSize: '0.92rem', display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
          <Info size={16} /> Randomized Monte Carlo & Parallel Execution Overhead Insights
        </h5>
        <p style={{ margin: 0, color: '#334155', lineHeight: 1.5 }}>
          Monte Carlo simulations run stochastic duration trials using triangular probability distributions to estimate surgical delay risks. For parallel algorithms, browser Web Workers partition large datasets across hardware CPU threads. For small arrays, thread instantiation & serialization overhead makes sequential execution faster, whereas large datasets achieve significant multi-core speedup.
        </p>
      </div>
    </div>
  );
};

export default CO6RandomizedParallel;
